# 🎨 UI Setup Guide - Level 1 Tingkat 1

## 📋 **Text Objects yang Harus Dibuat**

### **1. txtScore** - Score Display
- **Type:** Text
- **Name:** `txtScore`
- **Initial Text:** `Score: 0`
- **Position:** X: 50, Y: 50 (Top-left)
- **Font Size:** 32px
- **Font:** Bold atau Regular
- **Color:** White (#FFFFFF) atau Black (#000000) sesuai background
- **Align:** Left
- **Initially Visible:** YES

### **2. txtProgress** - Progress Display
- **Type:** Text
- **Name:** `txtProgress`
- **Initial Text:** `0/5 Items`
- **Position:** X: 50, Y: 90 (Below score)
- **Font Size:** 24px
- **Font:** Regular
- **Color:** White (#FFFFFF) atau Black (#000000)
- **Align:** Left
- **Initially Visible:** YES

### **3. txtCurrentTask** - Current Task Display
- **Type:** Text
- **Name:** `txtCurrentTask`
- **Initial Text:** `Tugas: Hitung Selimut`
- **Position:** X: 640, Y: 50 (Top-center)
- **Font Size:** 28px
- **Font:** Bold
- **Color:** Yellow (#FFFF00) atau White (#FFFFFF)
- **Align:** Center
- **Initially Visible:** YES

### **4. txtFeedback** - Feedback Popup
- **Type:** Text
- **Name:** `txtFeedback`
- **Initial Text:** `BENAR!`
- **Position:** X: 640, Y: 360 (Center screen)
- **Font Size:** 72px
- **Font:** Bold
- **Color:** Green (#00FF00) - akan berubah otomatis via script
- **Align:** Center
- **Initially Visible:** NO ❌ (Harus dimatikan!)

---

## 🎯 **Cara Membuat Text Objects di Construct 3**

### **Step-by-Step:**

1. **Open Layout** `Level1_Tingkat1`

2. **Insert Text Object:**
   - Right-click di layout
   - Pilih **"Insert new object"**
   - Cari dan pilih **"Text"**
   - Klik di posisi yang diinginkan

3. **Rename Object:**
   - Klik object yang baru dibuat
   - Di **Properties panel** (kanan), ubah **Name** sesuai tabel di atas
   - Contoh: `txtScore`, `txtProgress`, dll

4. **Set Properties:**
   - **Text:** Isi sesuai "Initial Text" di tabel
   - **Font:** Pilih font family dan size
   - **Color:** Klik color picker dan set warna
   - **Horizontal alignment:** Left/Center/Right
   - **Initially visible:** YES atau NO sesuai tabel

5. **Position:**
   - Drag object ke posisi yang benar, atau
   - Set **X** dan **Y** di Properties panel

6. **Ulangi** untuk keempat text objects!

---

## 🎨 **Styling Recommendations**

### **Background dengan Gambar Gelap:**
- **Score/Progress/Task:** White (#FFFFFF)
- **Feedback:** Green (#00FF00) / Red (#FF0000) / Gold (#FFD700)

### **Background Terang:**
- **Score/Progress/Task:** Black (#000000) atau Navy (#000080)
- **Feedback:** Dark Green (#008000) / Red (#FF0000) / Gold (#FFD700)

### **Font Recommendations:**
- **Score/Progress:** Arial, Roboto, atau Sans-serif
- **Current Task:** Impact, Arial Bold, atau Comic Sans MS
- **Feedback:** Impact, Arial Black, atau font Bold/Heavy

---

## 🧪 **Testing UI**

Setelah semua text objects dibuat:

1. **Save** project
2. **Reload** preview (Ctrl+Shift+R)
3. **Check console** untuk pastikan tidak ada error
4. **Klik icon** dan lihat:
   - ✅ Score bertambah
   - ✅ Progress update (1/5, 2/5, dst)
   - ✅ Popup "BENAR!" atau "SALAH!" muncul 2 detik
   - ✅ Current task berubah ke item berikutnya
   - ✅ Completion screen muncul setelah 5 item selesai

---

## ⚠️ **Troubleshooting**

### **Error: "txtScore is undefined"**
- **Penyebab:** Object name salah atau belum dibuat
- **Solusi:** Pastikan name PERSIS `txtScore` (case-sensitive!)

### **Text tidak muncul:**
- **Check:** Initially Visible harus YES (kecuali txtFeedback)
- **Check:** Layer visibility harus ON
- **Check:** Z-order - text harus di atas background

### **Text tertutup object lain:**
- **Solusi:** 
  - Klik text object
  - Right-click → **Z Order** → **Bring to front**

### **Warna tidak sesuai:**
- **Note:** Script akan auto-change warna txtFeedback
- **BENAR:** Green
- **SALAH:** Red
- **SELESAI:** Gold

---

## 📊 **UI Behavior**

### **On Game Start:**
```
Score: 0
0/5 Items
Tugas: Hitung Selimut
```

### **After Correct Answer:**
```
✅ BENAR!  (2 seconds popup)
Score: 150
1/5 Items
Tugas: Hitung Bantal
```

### **After Wrong Answer:**
```
❌ SALAH!  (2 seconds popup)
Score: 150  (tidak berubah)
1/5 Items
Tugas: Hitung Bantal  (tetap task yang sama)
```

### **On Completion:**
```
🎉 SELESAI!
⭐⭐⭐
Score: 750
```

---

## ✅ **Checklist**

- [ ] txtScore created with correct name and position
- [ ] txtProgress created with correct name and position
- [ ] txtCurrentTask created with correct name and position
- [ ] txtFeedback created with correct name and position
- [ ] txtFeedback Initially Visible = NO
- [ ] All text colors set appropriately
- [ ] All font sizes correct
- [ ] Tested in preview - UI updates correctly
- [ ] Feedback popup shows and hides after 2 seconds
- [ ] Completion screen shows after 5 items

---

**Developers:** Eko Muchamad Haryono & Anang Febryan Sutarja  
**Date:** November 10, 2025  
**Game:** NUMERI - Educational Counting Game
