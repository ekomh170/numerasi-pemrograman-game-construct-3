// ========================================
// GAME LOGIC - LEVEL 1 TINGKAT 1
// Counting Objects Game - FIXED VERSION
// ========================================

// Game state variables
let currentItem = 0;  // Current item being counted (0-4)
let score = 0;        // Player score
let itemsCompleted = 0; // Number of items completed
let isProcessing = false; // Prevent double clicks

// Item configuration
const items = [
	{ name: 'Selimut', objectName: '1selimutlvl1', correctCount: 2, iconName: 'benda1lvl1' },
	{ name: 'Bantal',  objectName: '2bantallvl1',  correctCount: 2, iconName: 'benda2lvl1' },
	{ name: 'Boneka',  objectName: '3bonekalvl1',  correctCount: 2, iconName: 'benda3lvl1' },
	{ name: 'Baju',    objectName: '4baju2lvl1',   correctCount: 2, iconName: 'benda4lvl1' },
	{ name: 'Buku',    objectName: '5bukulvl1',    correctCount: 3, iconName: 'benda5lvl1' }
];

// Initialize game on layout start
runtime.addEventListener("beforelayoutstart", () => {
	currentItem = 0;
	score = 0;
	itemsCompleted = 0;
	isProcessing = false;
	
	console.log('=================================');
	console.log('🎮 GAME INITIALIZED');
	console.log('Level 1 - Tingkat 1: Kamar Tidur');
	console.log('=================================');
	console.log('📝 Current task:', items[currentItem].name);
	console.log('💡 Hint: Count the', items[currentItem].name, 'in the room');
	console.log('');
});

// Function to check answer - DIPANGGIL DARI CONSTRUCT 3 EVENTS
function checkAnswer(itemIndex) {
	if (isProcessing) {
		console.log('⏳ Processing, please wait...');
		return;
	}
	
	if (itemIndex !== currentItem) {
		console.log('❌ Not this item\'s turn yet!');
		console.log('💡 Current task:', items[currentItem].name);
		return;
	}
	
	isProcessing = true;
	
	const item = items[itemIndex];
	
	// Get all instances of the object type
	const objectType = runtime.objects[item.objectName];
	
	if (!objectType) {
		console.error('❌ Object type not found:', item.objectName);
		console.log('Available objects:', Object.keys(runtime.objects));
		isProcessing = false;
		return;
	}
	
	const actualCount = objectType.getAllInstances().length;
	const expectedCount = item.correctCount;
	
	console.log('');
	console.log('🔍 Checking:', item.name);
	console.log('Expected:', expectedCount, '| Found:', actualCount);
	
	if (actualCount === expectedCount) {
		// CORRECT ANSWER
		const baseScore = 100;
		const bonusScore = 50; // Bonus untuk jawaban benar
		score += baseScore + bonusScore;
		itemsCompleted++;
		currentItem++;
		
		console.log('✅ CORRECT!', item.name);
		console.log('💰 Score: +' + (baseScore + bonusScore) + ' | Total:', score);
		console.log('📊 Progress:', itemsCompleted, '/5');
		console.log('');
		
		// Check if all items completed
		if (itemsCompleted === 5) {
			const stars = getStarRating(score);
			console.log('');
			console.log('=================================');
			console.log('🎉 CONGRATULATIONS!');
			console.log('=================================');
			console.log('🏆 GAME COMPLETED!');
			console.log('💰 Final Score:', score);
			console.log('⭐ Rating:', stars, 'stars');
			console.log('=================================');
			console.log('');
		} else {
			console.log('📝 Next task:', items[currentItem].name);
			console.log('💡 Hint: Count the', items[currentItem].name, 'in the room');
		}
	} else {
		// WRONG ANSWER
		console.log('❌ WRONG! Try again.');
		console.log('💡 Hint: Look carefully, count the', item.name, 'in the room');
		console.log('');
	}
	
	isProcessing = false;
}

// Calculate star rating based on score
function getStarRating(finalScore) {
	// Perfect score: 750 (5 items × 150)
	// 3 stars: 600+ (80% correct)
	// 2 stars: 450+ (60% correct)
	// 1 star: 300+ (40% correct)
	if (finalScore >= 600) return 3;
	if (finalScore >= 450) return 2;
	if (finalScore >= 300) return 1;
	return 0;
}

// Export function untuk dipanggil dari Construct 3
runOnStartup(async runtime => {
	// Register global functions
	globalThis.checkAnswer = checkAnswer;
	globalThis.getStarRating = getStarRating;
	
	console.log('✅ Game functions registered');
	console.log('Ready to play!');
	console.log('');
});

// ========================================
// CATATAN PENTING:
// ========================================
// Untuk menggunakan script ini di Construct 3:
//
// 1. Buat Event di Event Sheet:
//    Event: Mouse → On Left button Clicked on → benda1lvl1
//    Action: Scripts → Run JavaScript → checkAnswer(0)
//
// 2. Ulangi untuk icon lainnya:
//    - benda2lvl1 → checkAnswer(1)
//    - benda3lvl1 → checkAnswer(2)
//    - benda4lvl1 → checkAnswer(3)
//    - benda5lvl1 → checkAnswer(4)
//
// 3. ATAU gunakan Function:
//    Event: Mouse → On Left button Clicked on → benda1lvl1
//    Action: Functions → Call function "checkAnswer"
//            Parameter 0: 0 (number)
//
// ========================================
