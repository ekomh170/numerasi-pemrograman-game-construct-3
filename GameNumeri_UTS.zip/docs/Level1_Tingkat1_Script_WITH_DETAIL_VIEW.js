// ========================================
// GAME LOGIC - LEVEL 1 TINGKAT 1
// Counting Objects Game - WITH DETAIL VIEW
// ========================================

// Game state variables
let currentItem = 0;  // Current item being counted (0-4)
let score = 0;        // Player score
let itemsCompleted = 0; // Number of items completed
let isProcessing = false; // Prevent double clicks

// Item configuration
// iconName = object yang DI-KLIK oleh player (icon di UI)
// objectName = object yang DIHITUNG jumlahnya di scene (detail benda)
const items = [
	{ name: 'Selimut', objectName: '1selimutdetaillvl1', correctCount: 2, iconName: '1selimutlvl1' },
	{ name: 'Bantal',  objectName: '2bantaldetaillvl1',  correctCount: 2, iconName: '2bantallvl1' },
	{ name: 'Boneka',  objectName: '3bonekadetaillvl1',  correctCount: 2, iconName: '3bonekalvl1' },
	{ name: 'Baju',    objectName: '4bajudetaillvl1',    correctCount: 2, iconName: '4baju1lvl1' },
	{ name: 'Buku',    objectName: '5bukudetaillvl1',    correctCount: 3, iconName: '5bukulvl1' }
];

// Initialize game on layout start
runtime.addEventListener("beforelayoutstart", () => {
	currentItem = 0;
	score = 0;
	itemsCompleted = 0;
	isProcessing = false;
	
	console.log('=================================');
	console.log('🎮 GAME INITIALIZED');
	console.log('Level 1 - Tingkat 1: Kamar Tidur');
	console.log('=================================');
	console.log('📝 Current task:', items[currentItem].name);
	console.log('💡 Hint: Count the', items[currentItem].name, 'in the room');
	console.log('');
	
	// Hide all detail views at start
	hideAllDetailViews();
});

// Function to hide all detail views
function hideAllDetailViews() {
	for (let i = 1; i <= 5; i++) {
		const detailObjectName = 'benda' + i + 'lvl1';
		const detailObject = runtime.objects[detailObjectName];
		
		if (detailObject) {
			const instances = detailObject.getAllInstances();
			instances.forEach(inst => {
				inst.isVisible = false;
			});
		}
	}
	console.log('👁️ All detail views hidden');
}

// Function to show detail view
function showDetailView(itemIndex) {
	const detailObjectName = 'benda' + (itemIndex + 1) + 'lvl1';
	const detailObject = runtime.objects[detailObjectName];
	
	if (detailObject) {
		const instances = detailObject.getAllInstances();
		if (instances.length > 0) {
			// Show detail (set visible)
			instances[0].isVisible = true;
			console.log('👁️ Showing detail view:', detailObjectName);
			
			// Hide after 3 seconds
			setTimeout(() => {
				instances[0].isVisible = false;
				console.log('👁️ Detail view hidden');
			}, 3000);
		}
	} else {
		console.warn('⚠️ Detail object not found:', detailObjectName);
	}
}

// Function to check answer - DIPANGGIL DARI CONSTRUCT 3 EVENTS
function checkAnswer(itemIndex) {
	if (isProcessing) {
		console.log('⏳ Processing, please wait...');
		return;
	}
	
	if (itemIndex !== currentItem) {
		console.log('❌ Not this item\'s turn yet!');
		console.log('💡 Current task:', items[currentItem].name);
		return;
	}
	
	isProcessing = true;
	
	// Show detail view of clicked item
	showDetailView(itemIndex);
	
	const item = items[itemIndex];
	
	// Get all instances of the object type
	const objectType = runtime.objects[item.objectName];
	
	if (!objectType) {
		console.error('❌ Object type not found:', item.objectName);
		console.log('Available objects:', Object.keys(runtime.objects));
		isProcessing = false;
		return;
	}
	
	const actualCount = objectType.getAllInstances().length;
	const expectedCount = item.correctCount;
	
	console.log('');
	console.log('🔍 Checking:', item.name);
	console.log('Expected:', expectedCount, '| Found:', actualCount);
	
	if (actualCount === expectedCount) {
		// CORRECT ANSWER
		const baseScore = 100;
		const bonusScore = 50; // Bonus untuk jawaban benar
		score += baseScore + bonusScore;
		itemsCompleted++;
		currentItem++;
		
		console.log('✅ CORRECT!', item.name);
		console.log('💰 Score: +' + (baseScore + bonusScore) + ' | Total:', score);
		console.log('📊 Progress:', itemsCompleted, '/5');
		console.log('');
		
		// Check if all items completed
		if (itemsCompleted === 5) {
			const stars = getStarRating(score);
			console.log('');
			console.log('=================================');
			console.log('🎉 CONGRATULATIONS!');
			console.log('=================================');
			console.log('🏆 GAME COMPLETED!');
			console.log('💰 Final Score:', score);
			console.log('⭐ Rating:', stars, 'stars');
			console.log('=================================');
			console.log('');
		} else {
			console.log('📝 Next task:', items[currentItem].name);
			console.log('💡 Hint: Count the', items[currentItem].name, 'in the room');
		}
	} else {
		// WRONG ANSWER
		console.log('❌ WRONG! Try again.');
		console.log('💡 Hint: Look carefully, count the', item.name, 'in the room');
		console.log('');
	}
	
	isProcessing = false;
}

// Calculate star rating based on score
function getStarRating(finalScore) {
	// Perfect score: 750 (5 items × 150)
	// 3 stars: 600+ (80% correct)
	// 2 stars: 450+ (60% correct)
	// 1 star: 300+ (40% correct)
	if (finalScore >= 600) return 3;
	if (finalScore >= 450) return 2;
	if (finalScore >= 300) return 1;
	return 0;
}

// Export function untuk dipanggil dari Construct 3
runOnStartup(async runtime => {
	// Register global functions
	globalThis.checkAnswer = checkAnswer;
	globalThis.getStarRating = getStarRating;
	globalThis.showDetailView = showDetailView;
	globalThis.hideAllDetailViews = hideAllDetailViews;
	
	console.log('✅ Game functions registered');
	console.log('Ready to play!');
	console.log('');
});

// ========================================
// CATATAN PENTING:
// ========================================
// Detail view objects (benda1lvl1 - benda5lvl1) akan:
// 1. TERSEMBUNYI saat game start
// 2. MUNCUL saat icon di-klik (3 detik)
// 3. HILANG otomatis setelah 3 detik
//
// Pastikan di Layout:
// - benda1lvl1 - benda5lvl1 ADA di layout
// - Position: Di tengah screen atau overlay
// - Initial visibility: TIDAK PENTING (akan di-set oleh script)
//
// ========================================
