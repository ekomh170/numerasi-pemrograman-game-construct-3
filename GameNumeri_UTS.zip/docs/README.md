# 📚 GameNumeri Documentation
## Complete Guide untuk NUMERI Educational Game

---

## 📋 Overview

Repository ini berisi dokumentasi lengkap untuk **NUMERI** - game edukasi berhitung untuk anak usia 4-6 tahun yang dibuat dengan Construct 3.

---

## 📁 Documentation Structure

### 🎮 Level Implementations

#### Level 1 - Tingkat 1
**Mechanic:** Counting + Click/Tap Detail View  
**Files:**
- [`Level1_Tingkat1_Mechanics.md`](./Level1_Tingkat1_Mechanics.md) - Game mechanic overview
- [`Level1_Tingkat1_Implementation.md`](./Level1_Tingkat1_Implementation.md) - Implementation guide
- [`Level1_Tingkat1_Script.js`](./Level1_Tingkat1_Script.js) - Basic script (no detail view)
- [`Level1_Tingkat1_Script_WITH_DETAIL_VIEW.js`](./Level1_Tingkat1_Script_WITH_DETAIL_VIEW.js) - Complete script with pop-up

**Status:** ✅ Complete & Production Ready

#### Level 1 - Tingkat 3
**Mechanic:** Drag & Drop Matching  
**Files:**
- [`Level1_Tingkat3_Setup.md`](./Level1_Tingkat3_Setup.md) - Complete setup guide
- [`Level1_Tingkat3_Code_Documentation.md`](./Level1_Tingkat3_Code_Documentation.md) - Detailed code documentation
- [`Level1_Tingkat3_Quick_Reference.md`](./Level1_Tingkat3_Quick_Reference.md) - Developer cheat sheet

**Status:** ✅ Complete & Production Ready

---

### 🛠️ General Guides

#### JavaScript Implementation
- [`CARA_IMPLEMENTASI_JavaScript.md`](./CARA_IMPLEMENTASI_JavaScript.md)
  - How to integrate JavaScript in Construct 3
  - Script registration process
  - Event sheet integration
  - Common patterns

#### Script Organization
- [`SCRIPT_ORGANIZATION.md`](./SCRIPT_ORGANIZATION.md)
  - Naming conventions (`lvl1t1_`, `lvl1t3_`, etc.)
  - File structure
  - Code organization best practices
  - Namespace management

#### UI Setup
- [`UI_SETUP_GUIDE.md`](./UI_SETUP_GUIDE.md)
  - Text objects setup
  - Button configuration
  - Layout guidelines
  - Responsive design tips

#### Detail View System
- [`DETAIL_VIEW_SYSTEM.md`](./DETAIL_VIEW_SYSTEM.md)
  - Pop-up detail mechanic
  - Click-to-zoom implementation
  - Animation patterns
  - Close button handling

---

### 🐛 Troubleshooting

#### Quick Fixes
- [`QUICK_FIX_Mouse_Click.md`](./QUICK_FIX_Mouse_Click.md)
  - Mouse click not working
  - Touch input issues
  - Event registration problems
  - Common C3 gotchas

---

## 🚀 Quick Start Guide

### For New Developers

1. **Read First:**
   - `CARA_IMPLEMENTASI_JavaScript.md` → Understand JS integration
   - `SCRIPT_ORGANIZATION.md` → Learn naming conventions

2. **Level 1 Tingkat 1 (Counting Game):**
   - Read `Level1_Tingkat1_Mechanics.md`
   - Follow `Level1_Tingkat1_Implementation.md`
   - Use `Level1_Tingkat1_Script_WITH_DETAIL_VIEW.js` as reference

3. **Level 1 Tingkat 3 (Drag & Drop):**
   - Read `Level1_Tingkat3_Setup.md` for complete setup
   - Check `Level1_Tingkat3_Quick_Reference.md` for quick lookup
   - Refer to `Level1_Tingkat3_Code_Documentation.md` for deep dive

4. **Setup UI:**
   - Follow `UI_SETUP_GUIDE.md` for text objects & buttons
   - Use `DETAIL_VIEW_SYSTEM.md` for pop-up mechanics

5. **Troubleshooting:**
   - Check `QUICK_FIX_Mouse_Click.md` for common issues

---

## 📊 Game Structure

```
NUMERI Game
│
├── Level 1: Kamar Tidur (Bedroom)
│   ├── Tingkat 1 ✅ → Count objects (1-5 items)
│   ├── Tingkat 2 ⏳ → Count objects (6-10 items)
│   └── Tingkat 3 ✅ → Match dolls (drag & drop)
│
├── Level 2: Ruang Tamu (Living Room)
│   ├── Tingkat 1 ⏳ → New counting challenges
│   └── Tingkat 2 ⏳ → Advanced counting
│
└── Main Menu ✅
    ├── Start button → Level 1 Tingkat 1
    ├── Settings (future)
    └── Exit
```

**Legend:**
- ✅ Complete & documented
- ⏳ Planned / In progress
- ❌ Not started

---

## 🎯 Documentation by Task

### I Want To...

#### ...Implement a New Level
1. Read `SCRIPT_ORGANIZATION.md` for naming
2. Copy structure from `Level1_Tingkat1_Implementation.md`
3. Create new script with unique prefix (e.g., `lvl2t1_`)
4. Follow event sheet pattern

#### ...Add Drag & Drop Mechanic
1. Read `Level1_Tingkat3_Setup.md`
2. Follow Step 1: Add Drag & Drop behaviors
3. Follow Step 2: Create overlap events
4. Test with `Level1_Tingkat3_Quick_Reference.md`

#### ...Add Pop-up Detail View
1. Read `DETAIL_VIEW_SYSTEM.md`
2. Use `Level1_Tingkat1_Script_WITH_DETAIL_VIEW.js` as template
3. Follow click event pattern
4. Add close button logic

#### ...Debug Mouse/Touch Issues
1. Check `QUICK_FIX_Mouse_Click.md`
2. Verify Touch object exists
3. Check event sheet conditions
4. Test with browser console (F12)

#### ...Setup Score Display
1. Read `UI_SETUP_GUIDE.md`
2. Create Text object named `txtScore`
3. Use `lvlXtY_updateScore()` pattern
4. Position at (50, 50) for consistency

#### ...Add Sound Effects
1. Import audio files to project
2. Add Audio object
3. Call `runtime.objects.AudioSuccess.play()` in success logic
4. See Enhancement sections in docs

---

## 🧩 Code Patterns

### Function Naming
```javascript
// ✅ Good - Level-specific prefix
lvl1t1_checkAnswer()
lvl1t3_checkMatch()
lvl2t1_countItems()

// ❌ Bad - No prefix (collision risk)
checkAnswer()
checkMatch()
countItems()
```

### Event Sheet Integration
```javascript
// Step 1: Export function in runOnStartup
export async function runOnStartup(runtime) {
  globalThis.lvl1t3_onDollDropped = lvl1t3_onDollDropped;
}

// Step 2: Call from event sheet
// Event: boneka1lvl1t3 → On drop
// Action: Run JavaScript → lvl1t3_onDollDropped(0);
```

### Console Logging
```javascript
// Use consistent format with emoji
console.log("[L1T3] 🎯 Action starting...");
console.log("[L1T3] ✅ Success!");
console.log("[L1T3] ❌ Error occurred");
console.log("[L1T3] 📊 Stats:", data);
```

### Layout Initialization
```javascript
runtime.addEventListener("beforelayoutstart", (event) => {
  if (event.layout.name === "YourLayoutName") {
    // Reset state here
    score = 0;
    matchedCount = 0;
  }
});
```

---

## 🔍 Search Guide

### Find by Topic

**Drag & Drop:**
- `Level1_Tingkat3_Setup.md` → Complete guide
- `Level1_Tingkat3_Quick_Reference.md` → Quick lookup

**Counting Mechanic:**
- `Level1_Tingkat1_Mechanics.md` → Overview
- `Level1_Tingkat1_Implementation.md` → Step-by-step

**Pop-up Detail:**
- `DETAIL_VIEW_SYSTEM.md` → System overview
- `Level1_Tingkat1_Script_WITH_DETAIL_VIEW.js` → Code example

**JavaScript Integration:**
- `CARA_IMPLEMENTASI_JavaScript.md` → General guide
- `SCRIPT_ORGANIZATION.md` → Structure & naming

**UI & Layout:**
- `UI_SETUP_GUIDE.md` → Text objects & buttons
- Each level's setup file → Specific coordinates

**Troubleshooting:**
- `QUICK_FIX_Mouse_Click.md` → Input issues
- Each level's setup file → Troubleshooting section

---

## 🛠️ Development Workflow

### 1. Planning Phase
- [ ] Define game mechanic
- [ ] Sketch layout & objects
- [ ] Choose prefix (e.g., `lvl2t1_`)
- [ ] Read relevant documentation

### 2. Implementation Phase
- [ ] Create layout in Construct 3
- [ ] Add all objects with correct names
- [ ] Create JavaScript file in `scripts/`
- [ ] Register script in `project.c3proj`
- [ ] Implement core logic
- [ ] Add event sheet integration

### 3. Testing Phase
- [ ] Preview in browser (F5)
- [ ] Open console (F12) for logs
- [ ] Test all interactions
- [ ] Test edge cases
- [ ] Mobile/touch testing

### 4. Polish Phase
- [ ] Add visual feedback (animations)
- [ ] Add audio feedback (sounds)
- [ ] Optimize performance
- [ ] Add error handling
- [ ] Update documentation

### 5. Documentation Phase
- [ ] Create setup guide (like `Level1_Tingkat3_Setup.md`)
- [ ] Create code documentation (like `Level1_Tingkat3_Code_Documentation.md`)
- [ ] Create quick reference (like `Level1_Tingkat3_Quick_Reference.md`)
- [ ] Update this README

---

## 📞 Support & Contribution

### Developers
- **Eko Muchamad Haryono** - [@ekomh170](https://github.com/ekomh170)
- **Anang Febryan Sutarja** - [@anangfebrr](https://github.com/anangfebrr)

### Repository
- **GitHub:** [numerasi-pemrograman-game-construct-3](https://github.com/ekomh170/numerasi-pemrograman-game-construct-3)
- **Issues:** Report bugs atau request features via GitHub Issues
- **Pull Requests:** Contributions welcome!

### Contact
- **Email:** [Your email here]
- **Discord/Slack:** [Your community link here]

---

## 📖 Additional Resources

### Construct 3 Documentation
- [Official Manual](https://www.construct.net/en/make-games/manuals/construct-3)
- [JavaScript Coding](https://www.construct.net/en/make-games/manuals/construct-3/scripting/overview)
- [Runtime API](https://www.construct.net/en/make-games/manuals/construct-3/scripting/scripting-reference)

### Learning Resources
- [Construct 3 Tutorials](https://www.construct.net/en/tutorials)
- [JavaScript ES6+ Guide](https://javascript.info/)
- [Game Design Patterns](https://gameprogrammingpatterns.com/)

### Tools
- **VS Code** - Recommended code editor
- **Browser DevTools** - For debugging (F12)
- **Git** - Version control

---

## 📝 Changelog

### November 10, 2025
- ✅ Added Level 1 Tingkat 3 complete documentation
  - Setup guide
  - Code documentation
  - Quick reference
- ✅ Created comprehensive README for docs folder
- ✅ Organized existing documentation
- ✅ Added search guide & workflow

### [Previous Dates]
- ✅ Level 1 Tingkat 1 documentation
- ✅ General implementation guides
- ✅ UI setup guide
- ✅ Troubleshooting docs

---

## 🎯 Roadmap

### Documentation Priorities

**High Priority:**
- [ ] Level 1 Tingkat 2 documentation (when implemented)
- [ ] Level 2 documentation (when implemented)
- [ ] Animation & Timeline guide
- [ ] Audio system guide

**Medium Priority:**
- [ ] Mobile optimization guide
- [ ] Performance optimization tips
- [ ] Testing strategy guide
- [ ] Deployment checklist

**Low Priority:**
- [ ] Advanced patterns & techniques
- [ ] Plugin integration guide
- [ ] Multiplayer considerations
- [ ] Monetization strategies

---

## 🏆 Best Practices Summary

### Code Quality
✅ Use consistent naming (prefix all functions/variables)  
✅ Add comprehensive console logging  
✅ Handle errors gracefully  
✅ Comment complex logic  
✅ Keep functions small & focused

### Documentation
✅ Document while coding (not after)  
✅ Include setup steps & troubleshooting  
✅ Add code examples & screenshots  
✅ Keep documentation up-to-date  
✅ Write for beginners

### Testing
✅ Test on multiple browsers  
✅ Test touch & mouse input  
✅ Test all edge cases  
✅ Use console for debugging  
✅ Test on actual mobile devices

---

**Last Updated:** November 10, 2025  
**Documentation Version:** 2.0  
**Game Version:** 1.0.0-alpha  
**Status:** 🚧 Active Development

---

**🎮 Happy Coding! Let's build an amazing educational game for kids! 🎉**
