# 📘 Level 1 Tingkat 3 - Code Documentation
## JavaScript Implementation Guide

---

## 📋 Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Global Variables](#global-variables)
3. [Configuration Data](#configuration-data)
4. [Core Functions](#core-functions)
5. [Helper Functions](#helper-functions)
6. [Initialization Functions](#initialization-functions)
7. [Best Practices](#best-practices)
8. [API Reference](#api-reference)

---

## 🏗️ Architecture Overview

### Design Pattern
**Namespace Pattern** dengan prefix `lvl1t3_` untuk menghindari naming collision.

### File Structure
```
scripts/level1_tingkat3.js (480 lines)
├── Header & Comments (Lines 1-25)
├── Global Variables (Lines 27-42)
├── Configuration Data (Lines 44-68)
├── Core Game Logic (Lines 70-320)
│   ├── lvl1t3_checkMatch() - Match detection & scoring
│   ├── lvl1t3_resetDollPosition() - Position reset
│   ├── lvl1t3_getStarRating() - Star calculation
│   ├── lvl1t3_updateScore() - Score UI update
│   ├── lvl1t3_updateProgress() - Progress UI update
│   ├── lvl1t3_showFeedback() - Visual/audio feedback
│   └── lvl1t3_showGameComplete() - Completion screen
├── Event Handlers (Lines 322-362)
│   └── lvl1t3_onDollDropped() - Drop event hook
├── Initialization (Lines 364-420)
│   ├── runOnStartup() - Global registration
│   └── OnBeforeProjectStart_L1T3() - Layout init
└── Export to Global Scope (Lines 422-480)
```

### Data Flow
```
User Action (Drop Boneka)
    ↓
Event Sheet (On drop + Is overlapping)
    ↓
lvl1t3_onDollDropped(dollIndex)
    ↓
lvl1t3_checkMatch(dollIndex, runtime)
    ↓
┌──────────────────────┐
│ testOverlap() Check  │
└──────────────────────┘
         │
    ┌────┴────┐
   YES       NO
    │         │
    ▼         ▼
[Match]  [Wrong]
    │         │
    ├─ Hide small doll
    ├─ Bounce big doll
    ├─ Score +150
    ├─ Update UI
    ├─ Check completion
    │
    └─► if (matchedCount == 5)
            └─► lvl1t3_showGameComplete()
                    └─► Navigate to Level2_Tingkat1
```

---

## 🔧 Global Variables

### Runtime Reference
```javascript
let lvl1t3_runtime = null;
```
**Purpose:** Store reference to Construct 3 runtime  
**Set:** During `runOnStartup()` hook  
**Usage:** Fallback when runtime not passed to functions  
**Type:** `IRuntime | null`

### Game State Variables
```javascript
let lvl1t3_score = 0;
let lvl1t3_matchedCount = 0;
let lvl1t3_isProcessing = false;
```

| Variable | Type | Default | Purpose |
|----------|------|---------|---------|
| `lvl1t3_score` | number | 0 | Total accumulated score (max 750) |
| `lvl1t3_matchedCount` | number | 0 | Number of correctly matched dolls (0-5) |
| `lvl1t3_isProcessing` | boolean | false | Lock flag to prevent double-processing during animations |

### Why Use Global State?
- ✅ Persist across multiple function calls
- ✅ Accessible from event sheet via exported functions
- ✅ Simple state management (no need for complex state library)

---

## ⚙️ Configuration Data

### Dolls Configuration Array
```javascript
let lvl1t3_dolls = [
  { id: 1, smallDoll: "boneka1lvl1t3", bigDoll: "boneka1lvl1t3out", matched: false },
  { id: 2, smallDoll: "boneka2lvl1t3", bigDoll: "boneka2lvl1t3out", matched: false },
  { id: 3, smallDoll: "boneka3lvl1t3", bigDoll: "boneka3lvl1t3out", matched: false },
  { id: 4, smallDoll: "boneka4lvl1t3", bigDoll: "boneka4lvl1t3out", matched: false },
  { id: 5, smallDoll: "boneka5lvl1t3", bigDoll: "boneka5lvl1t3out", matched: false }
];
```

**Structure:**
- `id` (number): Boneka number (1-5)
- `smallDoll` (string): Object name for draggable small doll
- `bigDoll` (string): Object name for drop target big doll
- `matched` (boolean): Track if this pair already matched

**Benefits:**
- Data-driven design (easy to modify)
- Loop through array for batch operations
- Track individual match status

### Original Positions (1280x720 Viewport)
```javascript
const originalPositions = [
  { x: 95, y: 315 },   // boneka1 - Kiri bawah kamar
  { x: 583, y: 54 },   // boneka2 - Atas rak/lemari
  { x: 197, y: 220 },  // boneka3 - Di kasur tengah
  { x: 557, y: 314 },  // boneka4 - Kanan bawah kamar
  { x: 441, y: 286 }   // boneka5 - Tengah bawah
];
```

**Important Notes:**
- Coordinates are for **1280x720 viewport**
- If layout uses 2560x1440, divide by 2
- Positions hardcoded (not read from layout JSON)
- Update manually if layout changes

---

## 🎮 Core Functions

### 1. lvl1t3_checkMatch()
**Purpose:** Main game logic - detect overlap, validate match, update score

**Signature:**
```javascript
function lvl1t3_checkMatch(dollIndex, runtime = null)
```

**Parameters:**
- `dollIndex` (number, required): Index 0-4 untuk boneka1-5
- `runtime` (IRuntime, optional): Construct 3 runtime reference

**Returns:** `void`

**Behavior:**
1. Validate dollIndex (0-4)
2. Get runtime reference (param or global)
3. Check if already matched (skip if true)
4. Get small doll instance from `rt.objects[smallDoll]`
5. Get big doll instance from `rt.objects[bigDoll]`
6. Check overlap: `smallInstance.testOverlap(bigInstance)`
7. **If match:**
   - Set `matched = true` in config
   - Hide small doll: `isVisible = false`
   - Bounce animation (scale 1.2x → 1.0x in 200ms)
   - Add 150 to score
   - Update UI (score, progress)
   - Show feedback (✅ COCOK!)
   - Check completion (if 5/5 → show completion)
8. **If no match:**
   - Show feedback (❌ SALAH!)
   - Auto-reset position to original coordinates

**Example Usage:**
```javascript
// From event sheet
lvl1t3_onDollDropped(0); // This internally calls checkMatch

// Direct call (testing)
lvl1t3_checkMatch(2, runtime); // Check boneka3
```

**Edge Cases Handled:**
- Invalid dollIndex → Log error and return
- Null runtime → Use global lvl1t3_runtime
- Already matched → Skip processing
- Object not found → Log error
- isProcessing lock → Prevent double-execution during animation

**Console Logs:**
```
[L1T3] 🎯 Checking match for boneka 3...
[L1T3] ✅ CORRECT! Boneka 3 matched!
[L1T3] 📊 Score: 450 | Progress: 3/5 boneka
[L1T3] ❌ Wrong match! Boneka 2 tidak cocok dengan target.
```

---

### 2. lvl1t3_resetDollPosition()
**Purpose:** Reset boneka kecil ke posisi awal (saat salah drop)

**Signature:**
```javascript
function lvl1t3_resetDollPosition(dollIndex, runtime = null)
```

**Parameters:**
- `dollIndex` (number, required): Index 0-4
- `runtime` (IRuntime, optional): Runtime reference

**Returns:** `void`

**Implementation:**
```javascript
const originalPositions = [
  { x: 95, y: 315 },
  { x: 583, y: 54 },
  { x: 197, y: 220 },
  { x: 557, y: 314 },
  { x: 441, y: 286 }
];

const pos = originalPositions[dollIndex];
const dollConfig = lvl1t3_dolls[dollIndex];
const dollObject = rt.objects[dollConfig.smallDoll];
const instance = dollObject.getFirstInstance();

instance.x = pos.x;
instance.y = pos.y;
```

**When Called:**
- After wrong match in `lvl1t3_checkMatch()`
- Can be called manually for reset button

**Console Log:**
```
[L1T3] 🔄 Reset boneka 2 ke posisi: 583, 54
```

---

### 3. lvl1t3_getStarRating()
**Purpose:** Calculate star rating based on final score

**Signature:**
```javascript
function lvl1t3_getStarRating(finalScore)
```

**Parameters:**
- `finalScore` (number, required): Total score achieved

**Returns:** `number` (0-3 stars)

**Algorithm:**
```javascript
if (finalScore >= 600) return 3;      // 80%+ = ⭐⭐⭐
else if (finalScore >= 450) return 2; // 60%+ = ⭐⭐
else if (finalScore >= 300) return 1; // 40%+ = ⭐
else return 0;                         // <40% = No stars
```

**Score Breakdown:**
- Perfect: 750 points (5 × 150) = 100%
- 3★ Threshold: 600 points = 80% = 4+ correct
- 2★ Threshold: 450 points = 60% = 3+ correct
- 1★ Threshold: 300 points = 40% = 2+ correct

---

### 4. lvl1t3_updateScore()
**Purpose:** Update score text object in UI

**Signature:**
```javascript
function lvl1t3_updateScore(runtime = null)
```

**Parameters:**
- `runtime` (IRuntime, optional): Runtime reference

**Returns:** `void`

**Implementation:**
```javascript
const scoreObject = rt.objects.txtScore;
if (scoreObject) {
  const instance = scoreObject.getFirstInstance();
  if (instance) {
    instance.text = `Score: ${lvl1t3_score}`;
  }
}
```

**Requirements:**
- Text object named `txtScore` must exist in layout
- If not found, function silently skips (no error)

---

### 5. lvl1t3_updateProgress()
**Purpose:** Update progress text object (e.g., "3/5 Boneka")

**Signature:**
```javascript
function lvl1t3_updateProgress(runtime = null)
```

**Parameters:**
- `runtime` (IRuntime, optional): Runtime reference

**Returns:** `void`

**Implementation:**
```javascript
const progressObject = rt.objects.txtProgress;
if (progressObject) {
  const instance = progressObject.getFirstInstance();
  if (instance) {
    instance.text = `${lvl1t3_matchedCount}/5 Boneka`;
  }
}
```

**Requirements:**
- Text object named `txtProgress` must exist
- Optional (won't break game if missing)

---

### 6. lvl1t3_showFeedback()
**Purpose:** Display feedback message (correct/wrong)

**Signature:**
```javascript
function lvl1t3_showFeedback(isCorrect, runtime = null)
```

**Parameters:**
- `isCorrect` (boolean, required): true = match, false = wrong
- `runtime` (IRuntime, optional): Runtime reference

**Returns:** `void`

**Behavior:**
```javascript
// Console logging (always)
if (isCorrect) {
  console.log("✅ COCOK! Boneka yang tepat!");
} else {
  console.log("❌ Bukan pasangan yang cocok. Coba lagi!");
}

// Text object feedback (if exists)
const feedbackObject = rt.objects.txtFeedback;
if (feedbackObject) {
  const instance = feedbackObject.getFirstInstance();
  instance.text = isCorrect ? "✅ COCOK!" : "❌ SALAH!";
  instance.isVisible = true;
  
  // Hide after 1.5 seconds
  setTimeout(() => {
    instance.isVisible = false;
  }, 1500);
}
```

**Design Decision:**
- **NO alert() popups** → alert() blocks game loop, annoying during testing
- Console logging → Always available for debugging
- Text object → Optional visual feedback
- Short duration (1.5s) → Quick feedback, don't block gameplay

---

### 7. lvl1t3_showGameComplete()
**Purpose:** Show completion screen with star rating and navigation

**Signature:**
```javascript
function lvl1t3_showGameComplete(runtime = null)
```

**Parameters:**
- `runtime` (IRuntime, optional): Runtime reference

**Returns:** `void`

**Implementation:**
```javascript
const finalScore = lvl1t3_score;
const stars = lvl1t3_getStarRating(finalScore);
const starDisplay = "⭐".repeat(stars);

const message = `
🎉 SELAMAT! Level 1 Tingkat 3 Selesai! 🎉

${starDisplay}

Score Akhir: ${finalScore}/750

Semua boneka sudah dicocokkan!
Kamu hebat! 🎊

Lanjut ke Level 2?
`;

const goToLevel2 = confirm(message);
if (goToLevel2) {
  rt.goToLayout("Level2_Tingkat1");
} else {
  console.log("[L1T3] 🏠 Player stay di Level 1 Tingkat 3");
}
```

**Alert vs Confirm:**
- Uses `confirm()` → User can choose to navigate or stay
- OK → Navigate to Level 2
- Cancel → Stay on current layout (replay?)

**Star Display:**
- 3★ = ⭐⭐⭐
- 2★ = ⭐⭐
- 1★ = ⭐
- 0★ = (empty)

**Timing:**
- Called 1.5 seconds after last match
- Delay allows bounce animation to complete

---

## 🛠️ Helper Functions

### 8. lvl1t3_onDollDropped()
**Purpose:** Event sheet hook function (called from "On drop" event)

**Signature:**
```javascript
function lvl1t3_onDollDropped(dollIndex)
```

**Parameters:**
- `dollIndex` (number, required): 0-4 for boneka1-5

**Returns:** `void`

**Implementation:**
```javascript
console.log(`[L1T3] 📦 Doll ${dollIndex + 1} dropped!`);
lvl1t3_checkMatch(dollIndex, lvl1t3_runtime);
```

**Purpose:**
- Simple wrapper for event sheet
- Logs drop event for debugging
- Passes global runtime to checkMatch

**Event Sheet Usage:**
```
Event: boneka1lvl1t3 → On drop
Condition: boneka1lvl1t3 → Is overlapping boneka1lvl1t3out
Action: Run JavaScript → lvl1t3_onDollDropped(0);
```

---

## 🚀 Initialization Functions

### 9. runOnStartup()
**Purpose:** Construct 3 startup hook - register functions to global scope

**Signature:**
```javascript
export async function runOnStartup(runtime)
```

**Parameters:**
- `runtime` (IRuntime, required): Construct 3 provides this automatically

**Returns:** `Promise<void>`

**What It Does:**
1. Store runtime reference: `lvl1t3_runtime = runtime`
2. Export 8 functions to `globalThis`:
   - `lvl1t3_onDollDropped`
   - `lvl1t3_checkMatch`
   - `lvl1t3_resetDollPosition`
   - `lvl1t3_updateScore`
   - `lvl1t3_updateProgress`
   - `lvl1t3_getStarRating`
   - `lvl1t3_showFeedback`
   - `lvl1t3_showGameComplete`
3. Log success: "✅ [L1T3] Game functions registered to global scope"

**Why Export to globalThis?**
- Event sheets can only call global functions
- `globalThis` makes functions accessible everywhere
- Alternative to using `window` object

**Console Log:**
```
✅ [L1T3] Game functions registered to global scope
```

---

### 10. OnBeforeProjectStart_L1T3()
**Purpose:** Layout-specific initialization - reset game state

**Signature:**
```javascript
export function OnBeforeProjectStart_L1T3(runtime)
```

**Parameters:**
- `runtime` (IRuntime, required): Construct 3 provides this

**Returns:** `void`

**What It Does:**
```javascript
runtime.addEventListener("beforelayoutstart", (event) => {
  const layoutName = event.layout.name;
  
  if (layoutName === "Level1_Tingkat3") {
    console.log("[L1T3] 🎮 Initializing Level 1 Tingkat 3...");
    
    // Reset game state
    lvl1t3_score = 0;
    lvl1t3_matchedCount = 0;
    lvl1t3_isProcessing = false;
    
    // Reset all dolls to unmatched
    lvl1t3_dolls.forEach(doll => {
      doll.matched = false;
    });
    
    // Update UI
    lvl1t3_updateScore(runtime);
    lvl1t3_updateProgress(runtime);
    
    console.log("[L1T3] ✅ Level initialized successfully!");
  }
});
```

**Why Layout-Specific?**
- Script loads once on project start
- But level can be replayed multiple times
- Need to reset state every time layout loads
- Prevents state leaking from previous playthrough

**When Triggered:**
- Before `Level1_Tingkat3` layout starts rendering
- NOT triggered for other layouts (Level1_Tingkat1, etc.)

---

## 📖 Best Practices

### Naming Convention
```javascript
// ✅ Good - Consistent prefix
let lvl1t3_score = 0;
function lvl1t3_checkMatch() { }

// ❌ Bad - No prefix (pollution)
let score = 0;
function checkMatch() { }
```

**Why Use Prefix?**
- Avoid naming collisions with other levels
- Easy to grep/search in codebase
- Clear ownership of variables/functions

### Error Handling
```javascript
// ✅ Good - Validate input
if (dollIndex < 0 || dollIndex >= lvl1t3_dolls.length) {
  console.error(`[L1T3] ❌ Invalid doll index: ${dollIndex}`);
  return;
}

// ✅ Good - Check if object exists
if (!dollObject) {
  console.error(`[L1T3] ❌ Object tidak ditemukan: ${smallDoll}`);
  return;
}

// ❌ Bad - Assume everything exists
const instance = rt.objects[dollName].getFirstInstance();
instance.x = 100; // Crash if object not found!
```

### Console Logging Strategy
```javascript
// Use emoji prefixes for quick visual scanning
console.log("[L1T3] 🎯 Checking match...");  // Action
console.log("[L1T3] ✅ Success!");            // Success
console.log("[L1T3] ❌ Error!");              // Error
console.log("[L1T3] 📊 Stats:");              // Data
console.log("[L1T3] 🔄 Reset...");            // Reset
console.log("[L1T3] 🎮 Initialize...");       // Init
console.log("[L1T3] 📦 Event triggered");     // Event
```

**Benefits:**
- Easy to filter in console: `/\[L1T3\]/`
- Visual scanning with emojis
- Consistent format across functions

### Performance Optimization
```javascript
// ✅ Cache object references
const dollObject = rt.objects[smallDoll];
const instance = dollObject.getFirstInstance();

// ❌ Don't repeat object lookups
rt.objects[smallDoll].getFirstInstance().x = 100;
rt.objects[smallDoll].getFirstInstance().y = 200;
```

### State Management
```javascript
// ✅ Use lock flag to prevent race conditions
if (lvl1t3_isProcessing) return;
lvl1t3_isProcessing = true;

// ... do processing ...

setTimeout(() => {
  lvl1t3_isProcessing = false;
}, animationDuration);
```

**Why Lock Flag?**
- Prevent double-processing during animation
- User might drop multiple dolls rapidly
- Overlap detection might trigger multiple times

---

## 📚 API Reference

### Exported Functions (Available in Event Sheet)

| Function | Parameters | Returns | Purpose |
|----------|------------|---------|---------|
| `lvl1t3_onDollDropped(dollIndex)` | `number` | `void` | Event sheet hook for drop event |
| `lvl1t3_checkMatch(dollIndex, runtime)` | `number, IRuntime?` | `void` | Main match detection logic |
| `lvl1t3_resetDollPosition(dollIndex, runtime)` | `number, IRuntime?` | `void` | Reset boneka to original position |
| `lvl1t3_updateScore(runtime)` | `IRuntime?` | `void` | Update score text object |
| `lvl1t3_updateProgress(runtime)` | `IRuntime?` | `void` | Update progress text object |
| `lvl1t3_getStarRating(finalScore)` | `number` | `number` | Calculate star rating (0-3) |
| `lvl1t3_showFeedback(isCorrect, runtime)` | `boolean, IRuntime?` | `void` | Show match feedback |
| `lvl1t3_showGameComplete(runtime)` | `IRuntime?` | `void` | Show completion screen |

### Global Variables (Internal Use)

| Variable | Type | Mutable | Purpose |
|----------|------|---------|---------|
| `lvl1t3_runtime` | `IRuntime \| null` | Yes | Runtime reference |
| `lvl1t3_score` | `number` | Yes | Current score (0-750) |
| `lvl1t3_matchedCount` | `number` | Yes | Matched count (0-5) |
| `lvl1t3_isProcessing` | `boolean` | Yes | Lock flag for animations |
| `lvl1t3_dolls` | `Array<DollConfig>` | Yes | Dolls configuration array |

### Type Definitions

```typescript
// DollConfig interface
interface DollConfig {
  id: number;           // 1-5
  smallDoll: string;    // Object name (e.g., "boneka1lvl1t3")
  bigDoll: string;      // Object name (e.g., "boneka1lvl1t3out")
  matched: boolean;     // Is this pair matched?
}

// Position interface
interface Position {
  x: number;
  y: number;
}
```

### Construct 3 Runtime API Used

```typescript
// Get object type
runtime.objects[objectName]: IObjectClass

// Get first instance of object
objectClass.getFirstInstance(): IWorldInstance

// Instance properties
instance.x: number
instance.y: number
instance.width: number
instance.height: number
instance.isVisible: boolean
instance.text: string (for Text objects)

// Collision detection
instance.testOverlap(otherInstance): boolean

// Navigation
runtime.goToLayout(layoutName: string): void
```

---

## 🔍 Debugging Tips

### Enable Verbose Logging
All console logs already included! Open browser console (F12) to see:
```
[L1T3] 🎮 Initializing Level 1 Tingkat 3...
[L1T3] ✅ Level initialized successfully!
[L1T3] 📦 Doll 1 dropped!
[L1T3] 🎯 Checking match for boneka 1...
[L1T3] ✅ CORRECT! Boneka 1 matched!
[L1T3] 📊 Score: 150 | Progress: 1/5 boneka
```

### Test Functions Manually
```javascript
// In browser console
lvl1t3_onDollDropped(0);  // Test boneka 1 drop
lvl1t3_checkMatch(2);     // Test boneka 3 match
lvl1t3_getStarRating(500); // Test star calculation → 2
lvl1t3_showGameComplete(); // Test completion screen
```

### Check Game State
```javascript
// In console
console.log("Score:", lvl1t3_score);
console.log("Matched:", lvl1t3_matchedCount);
console.log("Dolls:", lvl1t3_dolls);
```

### Common Errors & Solutions

**Error:** `lvl1t3_onDollDropped is not defined`
- **Cause:** Script not registered with `purpose: "imports-for-events"`
- **Fix:** Edit `project.c3proj`, change purpose, reload

**Error:** `Cannot read property 'x' of null`
- **Cause:** Object not found or no instances
- **Fix:** Check object names match exactly (case-sensitive)

**Error:** Match not detected
- **Cause:** Collision polygons don't overlap enough
- **Fix:** Increase collision polygon size or drag closer

---

## 📝 Changelog

### Version 1.0.0 (November 10, 2025)
- ✅ Initial implementation
- ✅ Drag & drop match mechanic
- ✅ Scoring system (150 per match, 750 max)
- ✅ Star rating (3/2/1 stars based on score)
- ✅ Visual feedback (bounce animation, console logs)
- ✅ Auto-reset on wrong match
- ✅ Completion screen with navigation
- ✅ Layout-specific initialization
- ✅ Global function exports
- ✅ Comprehensive error handling
- ✅ Optimized for 1280x720 viewport

---

## 👥 Credits

**Developers:**
- Eko Muchamad Haryono ([@ekomh170](https://github.com/ekomh170))
- Anang Febryan Sutarja ([@anangfebrr](https://github.com/anangfebrr))

**Project:** NUMERI - Educational Counting Game  
**Engine:** Construct 3  
**Language:** JavaScript ES6+  
**Target:** Children ages 4-6

---

**Last Updated:** November 10, 2025  
**Version:** 1.0.0  
**Status:** ✅ Production Ready
