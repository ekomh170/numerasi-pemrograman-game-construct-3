# 🎮 Implementation Guide - Level 1 Tingkat 1

## ⚠️ PENTING: Cara Menggunakan Guide Ini

Dokumen ini adalah **panduan step-by-step** untuk mengimplementasikan game mechanics di **Construct 3 Editor**.

Karena event system Construct 3 menggunakan visual block-based, implementasi harus dilakukan **langsung di editor**, bukan lewat edit JSON.

---

## 📋 Checklist: Persiapan Sebelum Mulai

### 1️⃣ Tambah Object Types Baru
Buka Construct 3 Editor → Project Panel → Right-click → Insert New Object:

#### Text Objects:
- [ ] `TextTaskInstruction` (Text)
  - Font: Arial, 24pt, Bold
  - Color: White
  - Position: Top center (640, 50)
  - Text: "Hitung berapa selimut yang ada?"

- [ ] `TextScore` (Text)
  - Font: Arial, 20pt
  - Color: Yellow
  - Position: Top right (1150, 30)
  - Text: "Skor: 0"

- [ ] `TextProgress` (Text)
  - Font: Arial, 18pt
  - Color: White
  - Position: Top left (100, 30)
  - Text: "1/5"

#### Feedback Sprites:
- [ ] `SpriteCheckmark` (Sprite)
  - Size: 64x64
  - Animation: Green checkmark ✅
  - Initially invisible

- [ ] `SpriteXMark` (Sprite)
  - Size: 64x64
  - Animation: Red X mark ❌
  - Initially invisible

#### UI Sprites:
- [ ] `SpriteStarEmpty` (Sprite) x3
  - Position: Center bottom
  - Gray star outline

- [ ] `SpriteStarFull` (Sprite) x3
  - Position: Same as empty stars
  - Gold filled star
  - Initially invisible

- [ ] `ButtonNext` (Sprite/Button)
  - Text: "Lanjut"
  - Position: Center bottom
  - Initially invisible

### 2️⃣ Tambah Global Variables
Project Panel → Right-click → Add Global Variable:

- [ ] `CurrentItem` (Number) = 0
- [ ] `Score` (Number) = 0
- [ ] `ItemsCompleted` (Number) = 0
- [ ] `AttemptsOnItem` (Number) = 0
- [ ] `IsProcessing` (Boolean) = false

### 3️⃣ Tambah Instance Variables pada Icon Objects
Select each icon object → Properties → Instance Variables:

**Untuk benda1lvl1 sampai benda5lvl1:**
- [ ] `itemIndex` (Number)
  - benda1lvl1: 0
  - benda2lvl1: 1
  - benda3lvl1: 2
  - benda4lvl1: 3
  - benda5lvl1: 4

- [ ] `correctCount` (Number)
  - benda1lvl1: 2 (selimut)
  - benda2lvl1: 2 (bantal)
  - benda3lvl1: 2 (boneka)
  - benda4lvl1: 2 (baju)
  - benda5lvl1: 3 (buku)

- [ ] `isActive` (Boolean) = false
- [ ] `isCompleted` (Boolean) = false

### 4️⃣ Tambah Behaviors
Untuk animasi smooth, tambahkan behaviors:

**Icon objects (benda1-5):**
- [ ] Tween behavior (untuk animasi pulse/shake)

**Detail objects:**
- [ ] Tween behavior (untuk scale animation)

---

## 💻 EVENT SHEET IMPLEMENTATION

Buka Event Sheet: **ES_Level1_Tingkat1**

### 📍 GROUP 1: INITIALIZATION

```
Group: "Initialization"
├─ Event: System → On start of layout
   ├─ Action: System → Set CurrentItem to 0
   ├─ Action: System → Set Score to 0
   ├─ Action: System → Set ItemsCompleted to 0
   ├─ Action: System → Set IsProcessing to false
   ├─ Action: TextScore → Set text to "Skor: 0"
   ├─ Action: TextProgress → Set text to "1/5"
   ├─ Action: SpriteCheckmark → Set visible to Invisible
   ├─ Action: SpriteXMark → Set visible to Invisible
   ├─ Action: ButtonNext → Set visible to Invisible
   ├─ Action: Functions → Call "InitializeIcons"
   └─ Action: Functions → Call "HighlightCurrentItem"
```

---

### 📍 GROUP 2: FUNCTIONS

```
Group: "Functions"
├─ Function: "InitializeIcons"
   ├─ Event: (no condition)
      ├─ Action: benda1lvl1 → Set isActive to false
      ├─ Action: benda1lvl1 → Set isCompleted to false
      ├─ Action: benda1lvl1 → Set opacity to 100
      ├─ (Repeat for benda2-5)
      └─ 
│
├─ Function: "HighlightCurrentItem"
   ├─ Comment: "Reset all detail objects opacity"
   ├─ Event: (no condition)
      ├─ Action: 1selimutdetaillvl1 → Set opacity to 50
      ├─ Action: 2bantaldetaillvl1 → Set opacity to 50
      ├─ Action: 3bonekadetaillvl1 → Set opacity to 50
      ├─ Action: 4bajudetaillvl1 → Set opacity to 50
      ├─ Action: 5bukudetaillvl1 → Set opacity to 50
      └─
   │
   ├─ Comment: "Highlight current item detail"
   ├─ Sub-event: CurrentItem = 0
      ├─ Action: 1selimutdetaillvl1 → Set opacity to 100
      ├─ Action: 1selimutdetaillvl1 → Tween scale to (1.1, 1.1) in 0.5s (Ease out)
      ├─ Action: benda1lvl1 → Set isActive to true
      └─ Action: TextTaskInstruction → Set text to "Hitung berapa SELIMUT yang ada?"
   │
   ├─ Sub-event: CurrentItem = 1
      ├─ Action: 2bantaldetaillvl1 → Set opacity to 100
      ├─ Action: 2bantaldetaillvl1 → Tween scale to (1.1, 1.1) in 0.5s
      ├─ Action: benda2lvl1 → Set isActive to true
      └─ Action: TextTaskInstruction → Set text to "Hitung berapa BANTAL yang ada?"
   │
   ├─ Sub-event: CurrentItem = 2
      ├─ Action: 3bonekadetaillvl1 → Set opacity to 100
      ├─ Action: 3bonekadetaillvl1 → Tween scale to (1.1, 1.1) in 0.5s
      ├─ Action: benda3lvl1 → Set isActive to true
      └─ Action: TextTaskInstruction → Set text to "Hitung berapa BONEKA yang ada?"
   │
   ├─ Sub-event: CurrentItem = 3
      ├─ Action: 4bajudetaillvl1 → Set opacity to 100
      ├─ Action: 4bajudetaillvl1 → Tween scale to (1.1, 1.1) in 0.5s
      ├─ Action: benda4lvl1 → Set isActive to true
      └─ Action: TextTaskInstruction → Set text to "Hitung berapa BAJU yang ada?"
   │
   └─ Sub-event: CurrentItem = 4
      ├─ Action: 5bukudetaillvl1 → Set opacity to 100
      ├─ Action: 5bukudetaillvl1 → Tween scale to (1.1, 1.1) in 0.5s
      ├─ Action: benda5lvl1 → Set isActive to true
      └─ Action: TextTaskInstruction → Set text to "Hitung berapa BUKU yang ada?"
│
├─ Function: "CheckAnswer" (Parameter: clickedItemIndex)
   ├─ Local Variable: actualCount (Number) = 0
   ├─ Local Variable: expectedCount (Number) = 0
   │
   ├─ Comment: "Get actual count based on item"
   ├─ Sub-event: Function.Param(0) = 0
      └─ Action: System → Set actualCount to 1selimutlvl1.Count
   ├─ Sub-event: Function.Param(0) = 1
      └─ Action: System → Set actualCount to 2bantallvl1.Count
   ├─ Sub-event: Function.Param(0) = 2
      └─ Action: System → Set actualCount to 3bonekalvl1.Count
   ├─ Sub-event: Function.Param(0) = 3
      └─ Action: System → Set actualCount to 4baju2lvl1.Count
   ├─ Sub-event: Function.Param(0) = 4
      └─ Action: System → Set actualCount to 5bukulvl1.Count
   │
   ├─ Comment: "Get expected count from icon"
   ├─ Event: (no condition)
      └─ Action: System → Pick benda(Function.Param(0)+1)lvl1
         └─ Action: System → Set expectedCount to benda.correctCount
   │
   ├─ Comment: "Check if answer is correct"
   ├─ Sub-event: actualCount = expectedCount
      ├─ Action: Functions → Call "OnCorrectAnswer"
   └─ Sub-event: Else
      └─ Action: Functions → Call "OnWrongAnswer"
│
├─ Function: "OnCorrectAnswer"
   ├─ Action: System → Set IsProcessing to true
   ├─ Action: Audio → Play "sfx_correct.wav"
   ├─ Action: System → Add 100 to Score
   ├─ Comment: "Bonus for first attempt"
   ├─ Sub-event: AttemptsOnItem = 0
      └─ Action: System → Add 50 to Score
   ├─ Action: System → Add 1 to ItemsCompleted
   ├─ Action: TextScore → Set text to "Skor: " & Score
   ├─ Action: TextProgress → Set text to ItemsCompleted & "/5"
   │
   ├─ Comment: "Show checkmark animation"
   ├─ Action: SpriteCheckmark → Set position to Mouse
   ├─ Action: SpriteCheckmark → Set visible to Visible
   ├─ Action: SpriteCheckmark → Tween scale from (0, 0) to (1.5, 1.5) in 0.3s
   ├─ Action: System → Wait 0.5 seconds
   ├─ Action: SpriteCheckmark → Set visible to Invisible
   │
   ├─ Comment: "Mark icon as completed"
   ├─ Event: (no condition - pick by itemIndex)
      └─ Action: Set current icon isCompleted to true
   │
   ├─ Action: System → Wait 0.5 seconds
   ├─ Action: System → Set AttemptsOnItem to 0
   │
   ├─ Comment: "Check if all items completed"
   ├─ Sub-event: ItemsCompleted = 5
      └─ Action: Functions → Call "ShowResults"
   └─ Sub-event: Else
      ├─ Action: System → Add 1 to CurrentItem
      ├─ Action: Functions → Call "HighlightCurrentItem"
      └─ Action: System → Set IsProcessing to false
│
├─ Function: "OnWrongAnswer"
   ├─ Action: Audio → Play "sfx_wrong.wav"
   ├─ Action: System → Add 1 to AttemptsOnItem
   │
   ├─ Comment: "Show X mark animation"
   ├─ Action: SpriteXMark → Set position to Mouse
   ├─ Action: SpriteXMark → Set visible to Visible
   ├─ Action: SpriteXMark → Tween angle to 360 in 0.5s
   ├─ Action: System → Wait 0.5 seconds
   └─ Action: SpriteXMark → Set visible to Invisible
│
└─ Function: "ShowResults"
   ├─ Action: Audio → Play "sfx_complete.wav"
   ├─ Action: TextTaskInstruction → Set text to "SELESAI! Skor Akhir: " & Score
   │
   ├─ Comment: "Calculate stars based on score"
   ├─ Sub-event: Score >= 600
      ├─ Action: SpriteStarFull → Set visible to Visible (all 3 stars)
      └─ Action: Audio → Play "sfx_star.wav" (3 times with delay)
   ├─ Sub-event: Score >= 450
      └─ Action: SpriteStarFull → Set visible to Visible (2 stars)
   ├─ Sub-event: Score >= 300
      └─ Action: SpriteStarFull → Set visible to Visible (1 star)
   │
   ├─ Action: System → Wait 2 seconds
   └─ Action: ButtonNext → Set visible to Visible
```

---

### 📍 GROUP 3: CLICK HANDLERS

```
Group: "Click Handlers"
├─ Event: Mouse → On Left button Clicked on benda1lvl1
   ├─ Sub-event: IsProcessing = false
   ├─ Sub-event: benda1lvl1.isActive = true
      └─ Action: Functions → Call "CheckAnswer" (Parameter: 0)
│
├─ Event: Mouse → On Left button Clicked on benda2lvl1
   ├─ Sub-event: IsProcessing = false
   ├─ Sub-event: benda2lvl1.isActive = true
      └─ Action: Functions → Call "CheckAnswer" (Parameter: 1)
│
├─ Event: Mouse → On Left button Clicked on benda3lvl1
   ├─ Sub-event: IsProcessing = false
   ├─ Sub-event: benda3lvl1.isActive = true
      └─ Action: Functions → Call "CheckAnswer" (Parameter: 2)
│
├─ Event: Mouse → On Left button Clicked on benda4lvl1
   ├─ Sub-event: IsProcessing = false
   ├─ Sub-event: benda4lvl1.isActive = true
      └─ Action: Functions → Call "CheckAnswer" (Parameter: 3)
│
├─ Event: Mouse → On Left button Clicked on benda5lvl1
   ├─ Sub-event: IsProcessing = false
   ├─ Sub-event: benda5lvl1.isActive = true
      └─ Action: Functions → Call "CheckAnswer" (Parameter: 4)
│
└─ Event: Mouse → On Left button Clicked on ButtonNext
   └─ Action: System → Go to layout "Level1_Tingkat2"
```

---

### 📍 GROUP 4: VISUAL EFFECTS

```
Group: "Visual Effects"
├─ Event: Every tick
   ├─ Sub-event: For each benda1lvl1 where isActive = true
      └─ Action: benda1lvl1 → Set opacity to 100 + sin(time*5)*20 (pulse effect)
   ├─ (Repeat for benda2-5)
   │
   └─ Sub-event: For each icon where isCompleted = true
      └─ Action: icon → Set opacity to 60 (dimmed)
```

---

## 🎨 ADDITIONAL POLISH (Optional)

### Hover Effects:
```
Event: Mouse → Cursor is over benda1lvl1
├─ Sub-event: benda1lvl1.isActive = true
   └─ Action: benda1lvl1 → Tween scale to (1.1, 1.1) in 0.2s

Event: Mouse → Cursor is NOT over benda1lvl1
   └─ Action: benda1lvl1 → Tween scale to (1.0, 1.0) in 0.2s
```

### Particle Effects (if particle object added):
```
On Correct Answer:
   → Spawn particles at icon position (confetti)

On Wrong Answer:
   → Spawn particles at icon position (smoke puff)
```

---

## 🔊 AUDIO ASSETS NEEDED

Place in `sounds/` folder:
- [ ] `sfx_click.wav` - Click sound
- [ ] `sfx_correct.wav` - Correct answer
- [ ] `sfx_wrong.wav` - Wrong answer
- [ ] `sfx_complete.wav` - Level complete
- [ ] `sfx_star.wav` - Star appear
- [ ] `bgm_level1.mp3` - Background music

---

## ✅ TESTING CHECKLIST

Setelah implementasi, test:
- [ ] Klik icon hanya berfungsi saat giliran item tersebut
- [ ] Counting system menghitung dengan benar
- [ ] Score bertambah sesuai aturan
- [ ] Progress bar update dengan benar
- [ ] Feedback visual muncul
- [ ] Audio play pada saat yang tepat
- [ ] Stars muncul sesuai score
- [ ] Next button muncul setelah selesai
- [ ] Tidak bisa klik saat IsProcessing = true

---

## 🐛 COMMON ISSUES & SOLUTIONS

### Issue 1: Icon bisa diklik saat tidak aktif
**Solution:** Tambah condition `isActive = true` di setiap click event

### Issue 2: Count tidak akurat
**Solution:** Pastikan nama object di layout match persis dengan nama di event

### Issue 3: Animation lag
**Solution:** Gunakan Tween behavior, bukan manual lerp

### Issue 4: Double click bug
**Solution:** Gunakan variable `IsProcessing` untuk prevent multiple clicks

---

## 📝 NOTES

1. **Construct 3 tidak support edit JSON langsung** untuk events yang complex
2. Semua event harus dibuat di **Event Sheet Editor** menggunakan visual blocks
3. Copy paste code di atas sebagai **reference guide** saat membuat events
4. Test setiap section sebelum lanjut ke section berikutnya

---

**Implementation Time Estimate:** 2-3 hours  
**Difficulty:** Medium  
**Developer:** Eko Muchamad Haryono & Anang Febryan Sutarja  
**Date:** November 10, 2025
