# 📁 Script Organization - NUMERI Game

## 🎯 **Script Structure**

Project ini sekarang menggunakan **modular script structure** dengan file terpisah per level:

```
scripts/
├── main.js                 ← Global initialization
└── level1_tingkat1.js      ← Level 1 Tingkat 1 logic
```

---

## 📝 **File Details**

### **1. main.js** - Global Script
**Purpose:** Global initialization dan project-wide functions

**Content:**
- Project startup message
- Global event listeners
- Shared utilities (future)

**Functions:** 
- `OnBeforeProjectStart()` - Project initialization
- `Tick()` - Global tick handler (for future use)

---

### **2. level1_tingkat1.js** - Level 1 Tingkat 1
**Purpose:** Game logic khusus untuk Level 1 Tingkat 1 (Kamar Tidur - Counting Game)

**Content:**
- Game state variables (score, progress, current item)
- Item configuration (5 objects to count)
- Game logic functions
- UI update functions
- Detail view system

**Functions:**
All functions menggunakan prefix `lvl1t1_` untuk avoid conflicts:
- `lvl1t1_checkAnswer(itemIndex)` - Main game logic
- `lvl1t1_showDetailView(itemIndex)` - Show detail popup
- `lvl1t1_hideAllDetailViews()` - Hide all popups
- `lvl1t1_updateUI()` - Update all UI elements
- `lvl1t1_showFeedback(isCorrect)` - Show BENAR/SALAH popup
- `lvl1t1_getStarRating(score)` - Calculate star rating

**Called From:**
- Event Sheet: `ES_Level1_Tingkat1`
- Mouse click events on icon objects

---

## 🔧 **How It Works**

### **1. Script Loading**
Construct 3 auto-loads scripts dari `project.c3proj`:
```json
"script": {
  "items": [
    { "name": "main.js", "purpose": "main" },
    { "name": "level1_tingkat1.js", "purpose": "none" }
  ]
}
```

### **2. Function Export**
Functions di-export ke `globalThis` dengan prefix:
```javascript
globalThis.lvl1t1_checkAnswer = (itemIndex) => lvl1t1_checkAnswer(itemIndex, runtime);
```

### **3. Event Sheet Calls**
Event sheets panggil function dengan prefix:
```javascript
// Mouse clicked on 1selimutlvl1
lvl1t1_checkAnswer(0);
```

### **4. Layout-Specific Initialization**
Script hanya init untuk layout yang sesuai:
```javascript
runtime.addEventListener("beforelayoutstart", (e) => {
  if (e.layout.name !== "Level1_Tingkat1") return;
  // Initialize level...
});
```

---

## ✅ **Benefits of This Structure**

1. **🔒 No Conflicts** - Function names dengan prefix unique per level
2. **📦 Modular** - Tiap level punya file sendiri, mudah maintain
3. **🚀 Scalable** - Mudah tambah level baru tanpa ganggu yang lain
4. **🧹 Clean** - main.js tetap minimal untuk global logic
5. **🔍 Easy Debug** - Console log jelas dari level mana (`[L1T1]`)

---

## 📂 **Future Structure (When Adding More Levels)**

```
scripts/
├── main.js                    ← Global
├── level1_tingkat1.js         ← L1T1: Kamar Tidur
├── level1_tingkat2.js         ← L1T2: Kamar Tidur (TBD)
├── level1_tingkat3.js         ← L1T3: Kamar Tidur (TBD)
├── level2_tingkat1.js         ← L2T1: Ruang Tamu (TBD)
└── level2_tingkat2.js         ← L2T2: Ruang Tamu (TBD)
```

---

## 🎮 **Adding New Level**

### **Template for New Level:**

```javascript
// ========================================
// LEVEL X TINGKAT Y - GAME LOGIC
// [Description]
// ========================================

// State variables with unique prefix
let lvlXtY_currentItem = 0;
let lvlXtY_score = 0;
// ...

// Functions with unique prefix
function lvlXtY_checkAnswer(itemIndex, runtime) {
  // Game logic...
}

// Export to global
runOnStartup(async runtime => {
  globalThis.lvlXtY_checkAnswer = (itemIndex) => 
    lvlXtY_checkAnswer(itemIndex, runtime);
  
  runtime.addEventListener("beforeprojectstart", () => 
    OnBeforeProjectStart_LvlXtY(runtime));
});

// Layout-specific initialization
async function OnBeforeProjectStart_LvlXtY(runtime) {
  runtime.addEventListener("beforelayoutstart", (e) => {
    if (e.layout.name !== "LevelX_TingkatY") return;
    // Initialize...
  });
}
```

### **Steps:**
1. **Create** `scripts/levelX_tingkatY.js`
2. **Add** to `project.c3proj` script items
3. **Create** Event Sheet with mouse events
4. **Call** functions with prefix `lvlXtY_checkAnswer()`

---

## 🔍 **Naming Convention**

| Level | Prefix | Example Function |
|-------|--------|------------------|
| L1T1 | `lvl1t1_` | `lvl1t1_checkAnswer()` |
| L1T2 | `lvl1t2_` | `lvl1t2_checkAnswer()` |
| L1T3 | `lvl1t3_` | `lvl1t3_checkAnswer()` |
| L2T1 | `lvl2t1_` | `lvl2t1_checkAnswer()` |
| L2T2 | `lvl2t2_` | `lvl2t2_checkAnswer()` |

**Format:** `lvl{level}t{tingkat}_{functionName}`

---

## 📊 **Console Log Format**

Semua log menggunakan prefix untuk easy debugging:
```javascript
console.log('✅ [L1T1] CORRECT! Selimut');
console.log('❌ [L1T2] WRONG! Try again.');
console.log('👁️ [L2T1] Showing detail view');
```

**Format:** `[LevelTingkat]` di setiap log message

---

## ⚠️ **Important Notes**

1. **Function Prefix:** ALWAYS gunakan prefix unique untuk setiap level
2. **Layout Check:** ALWAYS check layout name di `beforelayoutstart`
3. **Global Export:** ALWAYS export functions ke `globalThis`
4. **Console Log:** ALWAYS include level prefix di log messages
5. **Project Config:** ALWAYS register script di `project.c3proj`

---

**Developers:** Eko Muchamad Haryono & Anang Febryan Sutarja  
**Date:** November 10, 2025  
**Game:** NUMERI - Educational Counting Game
