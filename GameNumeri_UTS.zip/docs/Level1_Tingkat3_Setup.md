# 🎮 Level 1 Tingkat 3 - Match the Dolls
## Setup & Implementation Guide

## 📋 Overview
Level ini menggunakan mekanisme **Drag & Drop** dimana player harus mencocokkan boneka kecil dengan boneka besar yang sesuai.

---

## 🎯 Game Mechanic

### Objective
Drag boneka KECIL dari dalam kamar ke boneka BESAR di bagian bawah yang cocok berdasarkan **warna** dan **jenis hewan**.

### Game Rules
1. ✅ **Match Correct**: Boneka kecil hilang, score +150, boneka besar bounce
2. ❌ **Match Wrong**: Boneka kecil kembali ke posisi awal, tidak ada penalty
3. 🏆 **Completion**: Semua 5 boneka matched → Show rating & navigate ke Level 2

### Objects

**Boneka Kecil (Draggable) - Di Dalam Kamar:**
| No | Object Name | Jenis | Warna | Posisi | Koordinat (x,y) |
|----|-------------|-------|-------|--------|-----------------|
| 1 | `boneka1lvl1t3` | Tiger | Orange | Kiri bawah | (95, 315) |
| 2 | `boneka2lvl1t3` | Tiger | Kuning | Atas lemari | (583, 54) |
| 3 | `boneka3lvl1t3` | Giraffe | Krem | Di kasur | (197, 220) |
| 4 | `boneka4lvl1t3` | Tiger | Orange | Kanan bawah | (557, 314) |
| 5 | `boneka5lvl1t3` | Lion | Kuning | Tengah bawah | (441, 286) |

**Boneka Besar (Drop Target) - Area Abu-abu Bawah:**
| No | Object Name | Jenis | Warna | Angka | Deskripsi |
|----|-------------|-------|-------|-------|-----------|
| 1 | `boneka1lvl1t3out` | Tiger | Orange | 1️⃣ | Tiger orange dengan angka 1 |
| 2 | `boneka2lvl1t3out` | Tiger | Kuning | 2️⃣ | Tiger kuning dengan angka 2 |
| 3 | `boneka3lvl1t3out` | Giraffe | Krem | 3️⃣ | Giraffe dengan angka 3 |
| 4 | `boneka4lvl1t3out` | Tiger | Orange | 4️⃣ | Tiger orange dengan angka 4 |
| 5 | `boneka5lvl1t3out` | Lion | Kuning | 5️⃣ | Lion kuning dengan angka 5 |

### Matching Pairs
```
boneka1lvl1t3 (Tiger Orange) → boneka1lvl1t3out (Tiger ❶)
boneka2lvl1t3 (Tiger Kuning) → boneka2lvl1t3out (Tiger ❷)
boneka3lvl1t3 (Giraffe)      → boneka3lvl1t3out (Giraffe ❸)
boneka4lvl1t3 (Tiger Orange) → boneka4lvl1t3out (Tiger ❹)
boneka5lvl1t3 (Lion Kuning)  → boneka5lvl1t3out (Lion ❺)
```

### Scoring System
- **150 poin** per boneka yang cocok
- **Perfect Score**: 750 poin (5 × 150)
- **No Penalty**: Salah match tidak mengurangi score
- **Star Rating**:
  - ⭐⭐⭐ **3 stars**: 600+ poin (80%+ = 4-5 correct)
  - ⭐⭐ **2 stars**: 450+ poin (60%+ = 3-4 correct)
  - ⭐ **1 star**: 300+ poin (40%+ = 2-3 correct)

---

## 🛠️ Implementation Steps

### Step 1: Add Drag & Drop Behavior

1. **Buka Layout**: `Level1_Tingkat3`
2. **Pilih object** `boneka1lvl1t3` di layout
3. **Properties panel** (kanan) → **Behaviors** → Click **"Add new behavior"**
4. **Pilih "Drag & Drop"** dari list
5. **Ulangi** untuk `boneka2lvl1t3`, `boneka3lvl1t3`, `boneka4lvl1t3`, `boneka5lvl1t3`

**Drag & Drop Settings (Gunakan Default):**
```
✅ Enabled: Yes
✅ Drag horizontal: Yes
✅ Drag vertical: Yes
✅ Drop: (biarkan kosong)
```

### Step 2: Setup Event Sheet

**Buka Event Sheet**: `ES_Level1_Tingkat3`

#### Event 1: Boneka 1 Match
```
Add Event → boneka1lvl1t3 → On drop
Add Condition → boneka1lvl1t3 → Is overlapping boneka1lvl1t3out
Add Action → System → Run JavaScript
  Code: lvl1t3_onDollDropped(0);
```

#### Event 2: Boneka 2 Match
```
Add Event → boneka2lvl1t3 → On drop
Add Condition → boneka2lvl1t3 → Is overlapping boneka2lvl1t3out
Add Action → System → Run JavaScript
  Code: lvl1t3_onDollDropped(1);
```

#### Event 3: Boneka 3 Match
```
Add Event → boneka3lvl1t3 → On drop
Add Condition → boneka3lvl1t3 → Is overlapping boneka3lvl1t3out
Add Action → System → Run JavaScript
  Code: lvl1t3_onDollDropped(2);
```

#### Event 4: Boneka 4 Match
```
Add Event → boneka4lvl1t3 → On drop
Add Condition → boneka4lvl1t3 → Is overlapping boneka4lvl1t3out
Add Action → System → Run JavaScript
  Code: lvl1t3_onDollDropped(3);
```

#### Event 5: Boneka 5 Match
```
Add Event → boneka5lvl1t3 → On drop
Add Condition → boneka5lvl1t3 → Is overlapping boneka5lvl1t3out
Add Action → System → Run JavaScript
  Code: lvl1t3_onDollDropped(4);
```

### Step 3: Verify Script Registration

**Check `project.c3proj`:**
```json
{
  "name": "level1_tingkat3.js",
  "type": "application/javascript",
  "sid": 305400661433029,
  "script-info": {
    "purpose": "imports-for-events"  // ✅ HARUS "imports-for-events"
  }
}
```

**Jika purpose = "none":**
1. Tutup Construct 3
2. Edit `project.c3proj` → Ganti `"purpose": "none"` menjadi `"purpose": "imports-for-events"`
3. Save & buka lagi Construct 3

---

## 🎨 Visual Feedback System

### Saat Match Benar ✅:
1. **Boneka kecil hilang** (`isVisible = false`)
2. **Boneka besar bounce**:
   - Scale up 1.2x (200ms)
   - Scale back 1.0x
3. **Console log**: "✅ COCOK! Score: XXX | Progress: X/5"
4. **Score display update** (jika ada Text object)
5. **Progress display update** (jika ada Text object)

### Saat Match Salah ❌:
1. **Boneka kecil auto reset** ke posisi awal
2. **Console log**: "❌ Bukan pasangan yang cocok. Coba lagi!"
3. **Text feedback** (jika ada): "❌ SALAH!" (1.5 detik)

### Saat Game Complete 🎉:
1. **Alert popup** dengan:
   - Congratulations message
   - Star rating (⭐⭐⭐)
   - Final score
   - Button: OK → Navigate ke Level 2, Cancel → Stay
2. **Console log**: Detailed completion stats

---

## 📊 Game Flow Diagram

```
┌─────────────────────────────────────────────────────┐
│           LAYOUT START: Level1_Tingkat3            │
│                                                     │
│  Initialize:                                        │
│    - score = 0                                      │
│    - matchedCount = 0                              │
│    - All dolls marked as unmatched                 │
└─────────────────────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────┐
│              PLAYER DRAGS BONEKA KECIL              │
│                                                     │
│  Mouse down → Drag started                          │
│  Mouse move → Following cursor                      │
└─────────────────────────────────────────────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────┐
│          PLAYER DROPS ON BONEKA BESAR               │
│                                                     │
│  Mouse up → Trigger "On drop" event                 │
└─────────────────────────────────────────────────────┘
                        │
                        ▼
          ┌─────────────────────────┐
          │  Check Overlap          │
          │  Is overlapping         │
          │  correct big doll?      │
          └─────────────────────────┘
                │             │
           YES  │             │  NO
                │             │
        ┌───────▼──────┐   ┌──▼────────────┐
        │  MATCH! ✅    │   │  WRONG! ❌     │
        │              │   │               │
        │ - Hide small │   │ - Reset to    │
        │ - Bounce big │   │   original    │
        │ - Score +150 │   │   position    │
        │ - Log        │   │ - Log error   │
        └───────┬──────┘   └───────────────┘
                │
                ▼
      ┌──────────────────────┐
      │  matchedCount == 5?  │
      └──────────────────────┘
                │        │
           YES  │        │  NO
                │        │
        ┌───────▼──────┐ │
        │  COMPLETE! 🎉 │ │
        │              │ │
        │ - Calculate  │ │
        │   stars      │ │
        │ - Show alert │ │
        │ - Navigate   │ │
        │   Level 2    │ │
        └──────────────┘ │
                         │
                    ┌────▼────┐
                    │ Continue│
                    │ Playing │
                    └─────────┘
```

---

## 🐛 Troubleshooting

### Problem 1: Boneka tidak bisa di-drag
**Symptoms:**
- Click boneka tidak ada respon
- Boneka tidak follow cursor

**Solution:**
1. ✅ Pastikan **Drag & Drop behavior** sudah ditambahkan ke semua boneka kecil (boneka1-5lvl1t3)
2. Check behavior properties: `Enabled = Yes`, `Drag horizontal = Yes`, `Drag vertical = Yes`
3. Check object collision polygon: Harus ada collision shape yang cukup besar

### Problem 2: Script error "lvl1t3_onDollDropped is not defined"
**Symptoms:**
- Console error saat drop boneka
- Game tidak respon setelah drop

**Solution:**
1. Check `project.c3proj` → pastikan `level1_tingkat3.js` registered
2. Pastikan `"purpose": "imports-for-events"` (BUKAN "none")
3. Reload project (Ctrl+F5) atau restart Construct 3
4. Check console: Harus ada log `✅ [L1T3] Game functions registered to global scope`

### Problem 3: Match tidak terdeteksi (drop tidak match)
**Symptoms:**
- Drop boneka di atas target, tapi tidak ada respon
- Tidak ada log di console

**Solution:**
1. Check event sheet: Pastikan ada event "On drop" + condition "Is overlapping"
2. Pastikan kondisi overlap menggunakan boneka besar yang BENAR (boneka1lvl1t3out untuk boneka1lvl1t3)
3. Check collision polygons: Boneka kecil dan besar harus punya collision shape
4. Test dengan F12 → Console → coba manual: `lvl1t3_onDollDropped(0);`

### Problem 4: Boneka tidak kembali ke posisi awal saat salah
**Symptoms:**
- Drop di tempat salah, boneka tetap di situ
- Harus drag ulang dari posisi salah

**Solution:**
1. Script sudah ada `lvl1t3_resetDollPosition()` yang auto-call saat salah
2. Check posisi koordinat di script: Sesuaikan dengan layout actual
3. Alternative: Set Drag & Drop behavior → Drop = "No" (boneka auto kembali)

### Problem 5: Boneka besar tidak bounce/tidak ada visual feedback
**Symptoms:**
- Match benar, tapi boneka besar tidak ada animasi
- Boneka kecil hilang, tapi tidak smooth

**Solution:**
1. Check console log: Harus ada log "✅ CORRECT! Boneka X matched!"
2. Bounce effect menggunakan `width` dan `height`: Pastikan boneka besar tidak locked
3. Coba ganti bounce effect dengan opacity: 
   ```javascript
   bigDollInstance.opacity = 0.5;
   setTimeout(() => { bigDollInstance.opacity = 1; }, 200);
   ```

### Problem 6: Layout posisi boneka tidak match dengan script
**Symptoms:**
- Reset position salah tempat
- Boneka loncat ke lokasi random

**Solution:**
1. Cek koordinat aktual di layout (klik boneka → Properties → Position)
2. Update array `originalPositions` di fungsi `lvl1t3_resetDollPosition()`:
   ```javascript
   const originalPositions = [
     { x: 95, y: 315 },   // SESUAIKAN dengan layout
     { x: 583, y: 54 },
     // ...
   ];
   ```
3. Viewport 1280x720: Koordinat layout 2560x1440 harus dibagi 2

---

## 🎯 Tips untuk Player

### Strategi Bermain:
1. **Perhatikan warna** - Tiger orange vs Tiger kuning berbeda
2. **Lihat jenis hewan** - Tiger, Giraffe, Lion punya bentuk beda
3. **Gunakan angka sebagai clue** - Angka 1-5 di boneka besar
4. **Drag perlahan** - Construct 3 detect overlap saat mouse release
5. **Trial & error OK** - Tidak ada penalty untuk salah match

### Learning Points (Edukasi):
- 🔢 **Counting**: Ada 5 boneka (numerasi)
- 🎨 **Color Recognition**: Orange vs kuning
- 🐾 **Animal Recognition**: Tiger vs Giraffe vs Lion
- 🧩 **Pattern Matching**: Cocokkan yang sama
- 👁️ **Visual Observation**: Detail kecil yang berbeda

---

## 📝 Optional Enhancements

### Enhancement 1: Add Sound Effects
```javascript
// Di lvl1t3_checkMatch() setelah match benar:
if (isOverlapping) {
  // Play success sound
  rt.objects.AudioSuccess.play();
  
  // ...existing code...
}
```

### Enhancement 2: Add Particle Effect
```javascript
// Di lvl1t3_checkMatch() setelah match benar:
const particles = rt.objects.ParticleSparkle.getFirstInstance();
if (particles) {
  particles.x = bigDollInstance.x;
  particles.y = bigDollInstance.y;
  particles.isVisible = true;
  
  setTimeout(() => {
    particles.isVisible = false;
  }, 1000);
}
```

### Enhancement 3: Add Timer Challenge
```javascript
// Add di game state:
let lvl1t3_startTime = 0;
let lvl1t3_timeLimit = 60; // 60 detik

// Di layout start:
lvl1t3_startTime = Date.now();

// Check timeout:
setInterval(() => {
  const elapsed = (Date.now() - lvl1t3_startTime) / 1000;
  if (elapsed >= lvl1t3_timeLimit && lvl1t3_matchedCount < 5) {
    alert('⏰ Waktu habis! Coba lagi.');
    rt.goToLayout("Level1_Tingkat3"); // Restart
  }
}, 1000);
```

### Enhancement 4: Add Hint System
```javascript
function lvl1t3_showHint() {
  // Cari boneka yang belum matched
  const unmatchedDoll = lvl1t3_dolls.find(d => !d.matched);
  
  if (unmatchedDoll) {
    // Highlight boneka kecil dan besar yang cocok
    const smallDoll = rt.objects[unmatchedDoll.smallDoll].getFirstInstance();
    const bigDoll = rt.objects[unmatchedDoll.bigDoll].getFirstInstance();
    
    // Blink effect
    let blinkCount = 0;
    const blinkInterval = setInterval(() => {
      smallDoll.opacity = smallDoll.opacity === 1 ? 0.5 : 1;
      bigDoll.opacity = bigDoll.opacity === 1 ? 0.5 : 1;
      
      blinkCount++;
      if (blinkCount >= 6) {
        clearInterval(blinkInterval);
        smallDoll.opacity = 1;
        bigDoll.opacity = 1;
      }
    }, 300);
  }
}

// Export function
globalThis.lvl1t3_showHint = lvl1t3_showHint;
```

**Event Sheet untuk Hint:**
```
Keyboard → On key pressed → "H"
Action: Run JavaScript → lvl1t3_showHint();
```

---

## 🚀 Next Level: Level 2

Setelah Level 1 Tingkat 3 selesai dengan sempurna:
1. Player klik **OK** pada completion alert
2. Script execute: `rt.goToLayout("Level2_Tingkat1")`
3. Navigate ke **Level 2** dengan mekanik baru (Ruang Tamu)

**Preparation for Level 2:**
- Theme: Ruang Tamu
- New objects: Sofa, TV, Table, etc.
- Similar counting mechanic tapi lebih challenging
- More objects to count (7-10 items)

---

## 👥 Credits

**Developers:**
- Eko Muchamad Haryono ([@ekomh170](https://github.com/ekomh170))
- Anang Febryan Sutarja ([@anangfebrr](https://github.com/anangfebrr))

**Game Engine:** Construct 3  
**Project:** NUMERI - Educational Counting Game  
**Target:** Anak usia 4-6 tahun  
**Date:** November 10, 2025

---

## 📚 Related Documentation

- [`Level1_Tingkat1_Mechanics.md`](./Level1_Tingkat1_Mechanics.md) - Mechanics untuk Tingkat 1
- [`SCRIPT_ORGANIZATION.md`](./SCRIPT_ORGANIZATION.md) - Script structure & naming convention
- [`UI_SETUP_GUIDE.md`](./UI_SETUP_GUIDE.md) - Setup Text objects untuk UI
- [`CARA_IMPLEMENTASI_JavaScript.md`](./CARA_IMPLEMENTASI_JavaScript.md) - JavaScript implementation guide

---

**Last Updated:** November 10, 2025  
**Version:** 1.0.0  
**Status:** ✅ Production Ready

