# 📋 Detail View System - Level 1 Tingkat 1

## 🎯 Fitur Baru: Detail View Pop-up

Ketika player klik icon benda, akan muncul **detail view** selama **3 detik**.

---

## 🏗️ Struktur Object yang Dibutuhkan

### 1️⃣ **ICON Objects** (Yang DI-KLIK):
- `1selimutlvl1` → Icon selimut
- `2bantallvl1` → Icon bantal
- `3bonekalvl1` → Icon boneka
- `4baju1lvl1` → Icon baju
- `5bukulvl1` → Icon buku

### 2️⃣ **DETAIL Objects** (Yang DIHITUNG):
- `1selimutdetaillvl1` (2 buah di scene)
- `2bantaldetaillvl1` (2 buah di scene)
- `3bonekadetaillvl1` (2 buah di scene)
- `4bajudetaillvl1` (2 buah di scene)
- `5bukudetaillvl1` (3 buah di scene)

### 3️⃣ **DISPLAY Detail Objects** (Pop-up View):
- `benda1lvl1` → Detail view SELIMUT (gambar besar)
- `benda2lvl1` → Detail view BANTAL (gambar besar)
- `benda3lvl1` → Detail view BONEKA (gambar besar)
- `benda4lvl1` → Detail view BAJU (gambar besar)
- `benda5lvl1` → Detail view BUKU (gambar besar)

---

## 🎬 Flow Ketika Icon Diklik

```
Player klik 1selimutlvl1
    ↓
checkAnswer(0) dipanggil
    ↓
showDetailView(0) → Tampilkan benda1lvl1
    ↓
benda1lvl1.isVisible = true (3 detik)
    ↓
Cek count: 1selimutdetaillvl1 (harus 2)
    ↓
✅ Benar → Score +150
    ↓
setTimeout 3 detik
    ↓
benda1lvl1.isVisible = false (hilang)
```

---

## 📍 Setup di Layout

### Posisi Objects:

```
┌─────────────────────────────┐
│  LAYOUT: Level1_Tingkat1    │
│                              │
│  [Background Kamar Tidur]    │
│                              │
│  📌 1selimutdetaillvl1 (x2)  │
│  📌 2bantaldetaillvl1 (x2)   │
│  📌 3bonekadetaillvl1 (x2)   │
│  📌 4bajudetaillvl1 (x2)     │
│  📌 5bukudetaillvl1 (x3)     │
│                              │
│  ┌──────────────┐            │
│  │ ICON PANEL   │            │
│  ├──────────────┤            │
│  │ 🛏️ 🛏️ 🧸    │            │
│  │ 👕 📚        │            │
│  └──────────────┘            │
│                              │
│  ┌─────────────────────┐    │ (Layer atas)
│  │ 🔲 benda1lvl1       │    │ (Initially HIDDEN)
│  │    (Detail View)    │    │
│  └─────────────────────┘    │
└─────────────────────────────┘
```

### Properties Detail Objects (`benda1lvl1` - `benda5lvl1`):

- **Layer:** Top layer (paling atas)
- **Position:** Center screen (X: 640, Y: 360)
- **Size:** Besar (400x400 atau sesuai design)
- **Initial Visibility:** TIDAK PENTING (script akan set ke `false` saat start)
- **Z-Order:** Paling atas (overlay)

---

## ✅ Fungsi JavaScript Baru

### 1. `hideAllDetailViews()`
- Dipanggil saat game start
- Sembunyikan semua detail view (`benda1lvl1` - `benda5lvl1`)

### 2. `showDetailView(itemIndex)`
- Dipanggil saat icon diklik
- Tampilkan detail view yang sesuai
- Auto-hide setelah 3 detik

### 3. `checkAnswer(itemIndex)` - UPDATED
- Sekarang memanggil `showDetailView()` dulu
- Baru cek count
- Flow lebih natural

---

## 🧪 Testing Checklist

### ✅ **Test 1: Detail View Muncul**
1. Preview game
2. Klik icon `1selimutlvl1`
3. Harus muncul `benda1lvl1` (detail view)
4. Console: `👁️ Showing detail view: benda1lvl1`

### ✅ **Test 2: Detail View Hilang**
1. Tunggu 3 detik
2. `benda1lvl1` harus hilang otomatis
3. Console: `👁️ Detail view hidden`

### ✅ **Test 3: Sequence Benar**
1. Klik icon 1 → Detail 1 muncul → Cek count
2. Klik icon 2 → Detail 2 muncul → Cek count
3. Dst...

### ✅ **Test 4: All Hidden at Start**
1. Saat game mulai
2. Semua detail view harus tersembunyi
3. Console: `👁️ All detail views hidden`

---

## ⚠️ Troubleshooting

### ❌ Problem: Detail view tidak muncul

**Possible Causes:**
1. Object `benda1lvl1` - `benda5lvl1` TIDAK ADA di layout
2. Object di layer yang salah (tertutup layer lain)
3. Object terlalu kecil atau di luar screen

**Solutions:**
- Check Object Types panel: Apakah `benda1lvl1` - `benda5lvl1` ada?
- Check Layout: Apakah object ada instance-nya?
- Check layer order: Detail objects harus di top layer
- Check console: Ada warning `⚠️ Detail object not found`?

---

### ❌ Problem: Detail view tidak hilang

**Possible Causes:**
1. `setTimeout()` tidak jalan
2. Multiple clicks → Multiple timeouts

**Solutions:**
- Check `isProcessing` flag (prevent double click)
- Check console errors
- Manual test: Buka console, ketik `hideAllDetailViews()`

---

### ❌ Problem: Wrong detail muncul

**Example:** Klik selimut, tapi muncul boneka

**Cause:** Index salah di `showDetailView()`

**Solution:**
- Check parameter `checkAnswer(0)` untuk icon 1
- Check naming: `benda1lvl1` = index 0 (selimut)

---

## 🎨 Customization

### Ubah Durasi Tampil

Di `showDetailView()`, line:
```javascript
}, 3000);  // 3000ms = 3 detik
```

Ganti jadi:
- `2000` → 2 detik
- `5000` → 5 detik
- `1500` → 1.5 detik

---

### Tambah Animasi

Bisa tambah **tween/animation** sebelum hide:

```javascript
// Fade out animation (contoh)
setTimeout(() => {
	// Fade out selama 0.5 detik
	instances[0].behaviors.Fade.startFade(0, 0.5);
	
	// Baru hide setelah fade selesai
	setTimeout(() => {
		instances[0].isVisible = false;
	}, 500);
}, 2500);
```

---

### Tambah Sound Effect

```javascript
// Play sound saat detail muncul
runtime.objects.SoundEffect.play("pop.webm");
```

---

## 📝 Next Steps

1. ✅ Copy script baru ke Construct 3
2. ✅ Pastikan `benda1lvl1` - `benda5lvl1` ada di layout
3. ✅ Test dengan klik setiap icon
4. ✅ Adjust durasi/posisi jika perlu
5. 🎨 Tambah animasi/sound (optional)

---

**File Script:**
- `docs/Level1_Tingkat1_Script_WITH_DETAIL_VIEW.js`

**Developer Notes:**
- Created by: Eko Muchamad Haryono & Anang Febryan Sutarja
- Date: November 10, 2025
- Version: 2.0 (With Detail View)
