# 🎮 Cara Implementasi JavaScript di Construct 3
## Level 1 Tingkat 1 - Counting Game

---

## 📋 Prerequisites

✅ File JavaScript sudah dibuat: `docs/Level1_Tingkat1_Script.js`  
✅ Event Sheet: `ES_Level1_Tingkat1`  
✅ Layout: `Level1_Tingkat1`

---

## 🔧 Langkah 1: Tambah Script File

1. **Buka Project di Construct 3**
2. **Klik kanan** pada folder `Scripts` di panel Project
3. **Pilih:** `Add script` → `From file`
4. **Select:** `docs/Level1_Tingkat1_Script.js`
5. **Atau:** Klik `New script` → Copy-paste isi file JS

---

## 🎯 Langkah 2: Setup Click Events

Buka **Event Sheet** `ES_Level1_Tingkat1`

### 🖱️ Event 1: Icon Selimut (benda1lvl1)

**Add Event:**
```
Mouse → On Left button Clicked on → benda1lvl1
```

**Add Action:**
```
System → Run JavaScript → 
Code: checkAnswer(0);
```

---

### 🖱️ Event 2: Icon Bantal (benda2lvl1)

**Add Event:**
```
Mouse → On Left button Clicked on → benda2lvl1
```

**Add Action:**
```
System → Run JavaScript → 
Code: checkAnswer(1);
```

---

### 🖱️ Event 3: Icon Boneka (benda3lvl1)

**Add Event:**
```
Mouse → On Left button Clicked on → benda3lvl1
```

**Add Action:**
```
System → Run JavaScript → 
Code: checkAnswer(2);
```

---

### 🖱️ Event 4: Icon Baju (benda4lvl1)

**Add Event:**
```
Mouse → On Left button Clicked on → benda4lvl1
```

**Add Action:**
```
System → Run JavaScript → 
Code: checkAnswer(3);
```

---

### 🖱️ Event 5: Icon Buku (benda5lvl1)

**Add Event:**
```
Mouse → On Left button Clicked on → benda5lvl1
```

**Add Action:**
```
System → Run JavaScript → 
Code: checkAnswer(4);
```

---

## 🎨 Alternative: Gunakan Functions

Kalau mau lebih clean, bisa pakai **Functions Plugin**:

### 1️⃣ Buat Function "checkAnswer"

**Add Event:**
```
Functions → On function "checkAnswer"
```

**Add Parameter:**
- Name: `itemIndex`
- Type: `number`

**Add Action:**
```
System → Run JavaScript → 
Code: checkAnswer(Function.Param(0));
```

### 2️⃣ Panggil Function dari Click Events

**Event:**
```
Mouse → On Left button Clicked on → benda1lvl1
```

**Action:**
```
Functions → Call function "checkAnswer"
Parameter 0: 0
```

Ulangi untuk icon lainnya dengan parameter 1, 2, 3, 4.

---

## 🧪 Langkah 3: Testing

### Test Checklist:

1. **Preview Game** (F5)
2. **Buka Console** (F12)
3. **Lihat pesan:** `✅ Game functions registered`
4. **Klik Icon Selimut** (benda1) → Harus muncul:
   ```
   🔍 Checking: Selimut
   Expected: 2 | Found: 2
   ✅ CORRECT! Selimut
   💰 Score: +150 | Total: 150
   📊 Progress: 1 /5
   📝 Next task: Bantal
   ```

5. **Klik Icon lainnya** sesuai urutan
6. **Selesaikan semua 5 items**
7. **Lihat pesan akhir:**
   ```
   🎉 CONGRATULATIONS!
   🏆 GAME COMPLETED!
   💰 Final Score: 750
   ⭐ Rating: 3 stars
   ```

---

## 🐛 Troubleshooting

### ❌ Problem: "checkAnswer is not defined"

**Solution:** 
- Pastikan script file sudah di-add ke project
- Check console: harus ada pesan `✅ Game functions registered`

---

### ❌ Problem: Click tidak terdeteksi

**Solution:**
- Pastikan object `benda1lvl1` - `benda5lvl1` ada di layout
- Check collision poly: harus ada area clickable
- Test: Add event `Mouse → On any click` → Log to console

---

### ❌ Problem: "Object type not found"

**Solution:**
- Check nama object di Object Types panel
- Pastikan nama exactly match:
  - `1selimutlvl1`
  - `2bantallvl1`
  - `3bonekalvl1`
  - `4baju2lvl1`
  - `5bukulvl1`

---

### ❌ Problem: Count salah

**Solution:**
- Pastikan semua instances object ada di layout
- Check di Editor: Layout → Select object type → Lihat jumlah instances
- Expected counts:
  - Selimut: 2
  - Bantal: 2
  - Boneka: 2
  - Baju: 2
  - Buku: 3

---

## 🎯 Expected Behavior

### ✅ Correct Sequence:

1. Click **Selimut** (2 objects) → ✅ +150 score
2. Click **Bantal** (2 objects) → ✅ +150 score
3. Click **Boneka** (2 objects) → ✅ +150 score
4. Click **Baju** (2 objects) → ✅ +150 score
5. Click **Buku** (3 objects) → ✅ +150 score

**Total Score:** 750 → ⭐⭐⭐ (3 stars)

---

### ❌ Wrong Behavior:

- Click wrong icon → `❌ Not this item's turn yet!`
- Count wrong → `❌ WRONG! Try again.`
- Double click too fast → `⏳ Processing, please wait...`

---

## 📊 Scoring System

| Score Range | Stars | Grade |
|-------------|-------|-------|
| 600-750     | ⭐⭐⭐ | Perfect |
| 450-599     | ⭐⭐   | Good |
| 300-449     | ⭐     | OK |
| 0-299       | 💔     | Try Again |

**Calculation:**
- Base score per item: **100 points**
- Bonus per correct: **50 points**
- Total per item: **150 points**
- Max score (5 items): **750 points**

---

## 🚀 Next Steps

Setelah Level 1 Tingkat 1 selesai:

1. ✅ Test semua functionality
2. ✅ Fix bugs kalau ada
3. 🔄 Duplicate untuk Tingkat 2
4. 🔄 Duplicate untuk Tingkat 3
5. 🎨 Implement visual feedback (animations, sounds)
6. 🏆 Implement star rating UI
7. 💾 Implement save/load system

---

## 📝 Notes

- **JavaScript ini FIXED VERSION** - tidak ada infinite loop
- **Event handlers di-register SEKALI** saat layout start
- **Click detection via Construct 3 Events** - bukan JavaScript addEventListener
- **Console logs** untuk debugging - bisa dihapus untuk production

---

**Developer Notes:**
- Created by: Eko Muchamad Haryono & Anang Febryan Sutarja
- Date: November 10, 2025
- Version: 1.0 (Fixed)
