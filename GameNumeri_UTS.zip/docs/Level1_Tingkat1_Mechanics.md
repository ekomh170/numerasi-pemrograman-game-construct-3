# 🎮 Game Mechanics - Level 1 Tingkat 1: Counting Objects

## 📋 Overview
**Level 1 - Tingkat 1** mengajarkan anak untuk **menghitung jumlah benda** yang ada di kamar tidur dan mencocokkannya dengan icon yang sesuai.

**Level:** Level 1 - Kamar Tidur 🛏️  
**Tingkat:** Tingkat 1 (Easy - Counting)  
**Layout:** `Level1_Tingkat1.json`  
**Event Sheet:** `ES_Level1_Tingkat1.json`

---

## 🎯 Objective
Pemain harus menghitung berapa jumlah dari masing-masing benda (Selimut, Bantal, Boneka, Baju, Buku) yang tersebar di kamar, kemudian mengklik icon yang sesuai.

---

## 🧩 Game Objects

### 1. Detail Objects (Area Atas - Referensi Benda)
Menampilkan gambar besar sebagai referensi visual:
- `1selimutdetaillvl1` - Gambar selimut detail
- `2bantaldetaillvl1` - Gambar bantal detail
- `3bonekadetaillvl1` - Gambar boneka detail
- `4bajudetaillvl1` - Gambar baju detail
- `5bukudetaillvl1` - Gambar buku detail

**Fungsi:** Sebagai visual guide agar anak tahu benda apa yang harus dihitung.

---

### 2. Icon Objects (Rak Bawah - Tombol Interaktif)
Icon kecil yang bisa diklik:
- `benda1lvl1` - Icon Selimut (clickable)
- `benda2lvl1` - Icon Bantal (clickable)
- `benda3lvl1` - Icon Boneka (clickable)
- `benda4lvl1` - Icon Baju (clickable)
- `benda5lvl1` - Icon Buku (clickable)

**Fungsi:** Tombol yang diklik pemain untuk memilih benda yang ingin dihitung.

---

### 3. Scene Objects (Tersebar di Ruangan - Yang Dihitung)
Benda-benda yang tersebar di kamar:
- `1selimutlvl1` × 2 buah
- `2bantallvl1` × 2 buah
- `3bonekalvl1` × 2 buah
- `4baju2lvl1` × 2 buah
- `5bukulvl1` × 3 buah

**Fungsi:** Benda yang harus dihitung oleh pemain.

---

## 🎮 Game Flow

### Phase 1: Tutorial/Introduction
1. Game dimulai, maskot muncul
2. Maskot menjelaskan:
   - "Hitung berapa jumlah benda di kamar ini!"
   - "Klik icon yang sesuai dengan benda yang kamu temukan!"

### Phase 2: Gameplay Loop
```
LOOP untuk setiap jenis benda (1-5):
  1. Highlight detail object (misalnya: selimut detail bercahaya)
  2. Pemain mencari dan menghitung selimut di ruangan
  3. Pemain klik icon selimut (benda1lvl1)
  4. Sistem menghitung jumlah selimut yang ada
  5. Tampilkan feedback:
     - Jika BENAR: ✅ Suara benar + animasi + lanjut ke benda berikutnya
     - Jika SALAH: ❌ Suara salah + coba lagi
```

### Phase 3: Completion
1. Semua benda sudah dihitung dengan benar
2. Tampilkan skor final dan bintang
3. Tombol "Next Level" atau "Main Menu"

---

## 🔧 Mechanic Details

### A. Highlighting System
**Saat giliran benda tertentu:**
- Detail object yang aktif: **scale 1.1 + glow effect**
- Icon yang sesuai: **berkedip/pulse animation**
- Benda lain: **opacity 0.5 (semi-transparent)**

### B. Counting System
**Jumlah benda yang benar:**
```
Selimut (benda1): 2 buah (1selimutlvl1 count)
Bantal (benda2):  2 buah (2bantallvl1 count)
Boneka (benda3):  2 buah (3bonekalvl1 count)
Baju (benda4):    2 buah (4baju2lvl1 count)
Buku (benda5):    3 buah (5bukulvl1 count)
```

### C. Click Interaction
**Ketika icon diklik:**
1. Count berapa banyak object dengan nama sesuai yang ada di layout
2. Bandingkan dengan jawaban yang benar
3. Tampilkan feedback

### D. Feedback System
**Visual Feedback:**
- ✅ Benar: Icon beranimasi bounce + checkmark muncul
- ❌ Salah: Icon shake + X muncul + highlight benda yang benar

**Audio Feedback:**
- Benar: Sound effect "ding!" / "correct!"
- Salah: Sound effect "buzz" / "try again"

### E. Scoring System
```
Base Score per benda: 100 poin
Bonus jika benar pertama kali: +50 poin
Total maksimal: (100 + 50) × 5 = 750 poin

Rating Bintang:
⭐ 1 Bintang: 300-449 poin
⭐⭐ 2 Bintang: 450-599 poin
⭐⭐⭐ 3 Bintang: 600-750 poin
```

---

## 🎨 UI Elements Needed

### Additional Objects to Add:
1. **Text Object** - Display current task
   - "Hitung berapa selimut yang ada?"
   
2. **Score Text** - Display current score
   - "Skor: 450"

3. **Progress Bar** - Show completion (1/5, 2/5, dll)

4. **Feedback Sprite**
   - Checkmark (✅) untuk benar
   - X mark (❌) untuk salah

5. **Star Rating** - Display at end
   - 1-3 bintang sesuai performa

6. **Button "Next"** - Untuk lanjut ke level berikutnya

---

## 📝 Variables Needed

### Global Variables:
```javascript
CurrentItem = 0        // Item yang sedang aktif (0-4)
Score = 0              // Total skor pemain
ItemsCompleted = 0     // Jumlah item yang sudah selesai
AttemptsOnItem = 0     // Jumlah percobaan pada item saat ini
```

### Item Data (Array/Dictionary):
```javascript
Items = [
  {name: "Selimut", icon: "benda1lvl1", detail: "1selimutdetaillvl1", scene: "1selimutlvl1", correctCount: 2},
  {name: "Bantal",  icon: "benda2lvl1", detail: "2bantaldetaillvl1", scene: "2bantallvl1",  correctCount: 2},
  {name: "Boneka",  icon: "benda3lvl1", detail: "3bonekadetaillvl1", scene: "3bonekalvl1",  correctCount: 2},
  {name: "Baju",    icon: "benda4lvl1", detail: "4bajudetaillvl1",  scene: "4baju2lvl1",   correctCount: 2},
  {name: "Buku",    icon: "benda5lvl1", detail: "5bukudetaillvl1",  scene: "5bukulvl1",    correctCount: 3}
]
```

---

## 🎬 Animation States

### Icon States:
- **Idle:** Normal appearance
- **Active:** Pulse/glow effect (saat ini giliran item ini)
- **Correct:** Bounce + green glow
- **Wrong:** Shake + red flash

### Detail Object States:
- **Inactive:** Opacity 0.5
- **Active:** Scale 1.1 + glow
- **Completed:** Checkmark overlay

---

## 🔊 Audio Cues

### Sound Effects Needed:
1. `sfx_click.wav` - Saat klik icon
2. `sfx_correct.wav` - Jawaban benar
3. `sfx_wrong.wav` - Jawaban salah
4. `sfx_complete.wav` - Semua item selesai
5. `sfx_star.wav` - Munculkan bintang rating

### Background Music:
- `bgm_level1.mp3` - Music ceria untuk level 1

---

## 💻 Implementation Steps

### Step 1: Setup Variables
```
Add Global Variables:
- CurrentItem (number) = 0
- Score (number) = 0
- ItemsCompleted (number) = 0
```

### Step 2: Start of Layout
```
On Start of Layout:
→ Set CurrentItem to 0
→ Set Score to 0
→ Call Function "HighlightCurrentItem"
```

### Step 3: Click Handler
```
On benda1lvl1 clicked:
→ Call Function "CheckAnswer" (itemIndex = 0)

On benda2lvl1 clicked:
→ Call Function "CheckAnswer" (itemIndex = 1)

... (untuk semua 5 icon)
```

### Step 4: Check Answer Function
```
Function "CheckAnswer" (itemIndex):
  → Count objects matching current item type
  → If count = correctCount:
    → Play correct sound
    → Add score
    → Increment ItemsCompleted
    → Show checkmark
    → Wait 1 second
    → If ItemsCompleted = 5:
      → Call Function "ShowResults"
    → Else:
      → Increment CurrentItem
      → Call Function "HighlightCurrentItem"
  → Else:
    → Play wrong sound
    → Shake icon
    → Show try again message
```

### Step 5: Highlight Function
```
Function "HighlightCurrentItem":
  → Set all detail objects opacity to 0.5
  → Set current detail object opacity to 1.0
  → Set current detail object scale to 1.1
  → Set all icons to idle state
  → Set current icon to active state (pulse)
```

---

## 🎓 Educational Goals

### Skills Learned:
1. **Counting** - Menghitung benda 1-10
2. **Object Recognition** - Mengenali benda yang sama
3. **Visual Scanning** - Mencari benda di area
4. **Focus & Attention** - Konsentrasi menghitung
5. **Memory** - Mengingat jumlah yang sudah dihitung

### Difficulty Level:
- **Easy:** 5 jenis benda, masing-masing 2-3 buah
- **Total objects:** 11 buah
- **Age Target:** 4-6 tahun

---

## 🚀 Future Enhancements

### Version 1.1:
- [ ] Timer mode (count within time limit)
- [ ] Hints (highlight objects when stuck)
- [ ] Difficulty levels (easy/medium/hard)

### Version 1.2:
- [ ] Leaderboard
- [ ] Achievement badges
- [ ] More room themes

---

**Dokumen ini:** Game Mechanics untuk **Level 1 Tingkat 1** saja  
**Status:** Ready for Implementation  
**Next:** Buat mechanics untuk Level 1 Tingkat 2 & Tingkat 3  
**Last Updated:** November 10, 2025  
**Developers:** Eko Muchamad Haryono & Anang Febryan Sutarja
