# 🎯 Level 1 Tingkat 3 - Quick Reference
## Cheat Sheet untuk Developer

---

## 📦 File Locations
```
scripts/level1_tingkat3.js       → Main game logic
eventSheets/ES_Level1_Tingkat3.json  → Event sheet template
layouts/Level1_Tingkat3.json    → Layout with objects
docs/Level1_Tingkat3_Setup.md   → Full setup guide
docs/Level1_Tingkat3_Code_Documentation.md → Code docs
```

---

## 🎮 Object Names (HARUS PERSIS!)

### Draggable Dolls (Small)
```
boneka1lvl1t3   → Tiger Orange (kiri bawah)
boneka2lvl1t3   → Tiger Kuning (atas lemari)
boneka3lvl1t3   → Giraffe (di kasur)
boneka4lvl1t3   → Tiger Orange (kanan bawah)
boneka5lvl1t3   → Lion Kuning (tengah bawah)
```

### Drop Targets (Big)
```
boneka1lvl1t3out   → Tiger ❶
boneka2lvl1t3out   → Tiger ❷
boneka3lvl1t3out   → Giraffe ❸
boneka4lvl1t3out   → Tiger ❹
boneka5lvl1t3out   → Lion ❺
```

### Optional UI Objects
```
txtScore      → Text untuk "Score: 450"
txtProgress   → Text untuk "3/5 Boneka"
txtFeedback   → Text untuk "✅ COCOK!" / "❌ SALAH!"
```

---

## ⚙️ Setup Checklist

### ☐ Step 1: Add Behaviors
- [ ] `boneka1lvl1t3` → Add "Drag & Drop" behavior
- [ ] `boneka2lvl1t3` → Add "Drag & Drop" behavior
- [ ] `boneka3lvl1t3` → Add "Drag & Drop" behavior
- [ ] `boneka4lvl1t3` → Add "Drag & Drop" behavior
- [ ] `boneka5lvl1t3` → Add "Drag & Drop" behavior

### ☐ Step 2: Create Events (ES_Level1_Tingkat3)
```javascript
// Event 1
boneka1lvl1t3 → On drop
boneka1lvl1t3 → Is overlapping boneka1lvl1t3out
Script → lvl1t3_onDollDropped(0);

// Event 2
boneka2lvl1t3 → On drop
boneka2lvl1t3 → Is overlapping boneka2lvl1t3out
Script → lvl1t3_onDollDropped(1);

// Event 3
boneka3lvl1t3 → On drop
boneka3lvl1t3 → Is overlapping boneka3lvl1t3out
Script → lvl1t3_onDollDropped(2);

// Event 4
boneka4lvl1t3 → On drop
boneka4lvl1t3 → Is overlapping boneka4lvl1t3out
Script → lvl1t3_onDollDropped(3);

// Event 5
boneka5lvl1t3 → On drop
boneka5lvl1t3 → Is overlapping boneka5lvl1t3out
Script → lvl1t3_onDollDropped(4);
```

### ☐ Step 3: Verify Script Registration
1. Open `project.c3proj`
2. Find `level1_tingkat3.js`
3. Check: `"purpose": "imports-for-events"`
4. If "none" → Change to "imports-for-events"
5. Save & reload project

### ☐ Step 4: Test
1. Preview (F5)
2. Open console (F12)
3. Drag boneka1 to boneka1lvl1t3out
4. Check console: Should see "✅ CORRECT!"
5. Test all 5 dolls
6. Verify completion alert appears

---

## 📊 Game Constants

### Scoring
```javascript
SCORE_PER_MATCH = 150
MAX_SCORE = 750
PERFECT_SCORE = 750 (5 × 150)
```

### Star Thresholds
```javascript
3★ = 600+ points (80%+, 4-5 correct)
2★ = 450+ points (60%+, 3 correct)
1★ = 300+ points (40%+, 2 correct)
0★ = <300 points
```

### Timing
```javascript
BOUNCE_ANIMATION = 200ms
FEEDBACK_DURATION = 1500ms
COMPLETION_DELAY = 1500ms
```

### Viewport
```javascript
WIDTH = 1280
HEIGHT = 720
```

---

## 🔧 Key Functions

### Event Sheet Functions
```javascript
lvl1t3_onDollDropped(dollIndex)  // 0-4
```

### Core Logic
```javascript
lvl1t3_checkMatch(dollIndex, runtime)
lvl1t3_resetDollPosition(dollIndex, runtime)
lvl1t3_showGameComplete(runtime)
```

### UI Updates
```javascript
lvl1t3_updateScore(runtime)
lvl1t3_updateProgress(runtime)
lvl1t3_showFeedback(isCorrect, runtime)
```

### Helpers
```javascript
lvl1t3_getStarRating(finalScore)  // Returns 0-3
```

---

## 🐛 Common Issues & Quick Fixes

### Issue: Drag tidak work
**Fix:** Add Drag & Drop behavior ke boneka kecil

### Issue: Script error "not defined"
**Fix:** Change `purpose: "imports-for-events"` in project.c3proj

### Issue: Match tidak detected
**Fix:** Check collision polygon size & event sheet overlap condition

### Issue: Posisi reset salah
**Fix:** Update koordinat di `originalPositions` array (lines 157-187)

### Issue: Boneka loncat ke tempat random
**Fix:** Viewport 1280x720, bukan 2560x1440 (koordinat harus /2)

---

## 📝 Quick Code Snippets

### Test Match (Browser Console)
```javascript
lvl1t3_onDollDropped(0);  // Test boneka 1
```

### Check State
```javascript
console.log("Score:", lvl1t3_score);
console.log("Progress:", lvl1t3_matchedCount + "/5");
console.log("Dolls:", lvl1t3_dolls.map(d => d.matched));
```

### Force Completion
```javascript
lvl1t3_score = 750;
lvl1t3_matchedCount = 5;
lvl1t3_showGameComplete();
```

### Reset Game
```javascript
lvl1t3_score = 0;
lvl1t3_matchedCount = 0;
lvl1t3_dolls.forEach(d => d.matched = false);
lvl1t3_updateScore();
lvl1t3_updateProgress();
```

---

## 🎨 Console Log Patterns

```
[L1T3] 🎮 Initialize...      → Layout start
[L1T3] 📦 Doll X dropped!    → Drop event
[L1T3] 🎯 Checking match...   → Match detection
[L1T3] ✅ CORRECT!           → Match success
[L1T3] ❌ Wrong match!       → Match fail
[L1T3] 📊 Score: X | Y/5     → Stats update
[L1T3] 🔄 Reset position...   → Position reset
[L1T3] 🎉 GAME COMPLETE!     → All matched
```

---

## 🔗 Related Files

### Must Read First
- `Level1_Tingkat3_Setup.md` → Setup guide
- `Level1_Tingkat3_Code_Documentation.md` → Code details

### Reference
- `SCRIPT_ORGANIZATION.md` → Naming conventions
- `Level1_Tingkat1_Mechanics.md` → Similar mechanic example

---

## 📞 Support

**GitHub Issues:** https://github.com/ekomh170/numerasi-pemrograman-game-construct-3/issues  
**Developers:**
- [@ekomh170](https://github.com/ekomh170)
- [@anangfebrr](https://github.com/anangfebrr)

---

**Last Updated:** November 10, 2025  
**Version:** 1.0.0
