# 💾 Fitur Save Progress - Level 1 Tingkat 1

## 📋 Deskripsi
Sistem otomatis menyimpan progress/skor pemain menggunakan browser localStorage.

## ✅ Cara Kerja

### 1️⃣ **Saat Game Selesai**
- User menyelesaikan 5 benda → Dapat skor & bintang
- System **OTOMATIS MENYIMPAN** ke localStorage:
  ```javascript
  lvl1t1_completed = 'true'
  lvl1t1_finalScore = '750'
  lvl1t1_finalStars = '3'
  lvl1t1_finalTime = '45'
  ```

### 2️⃣ **Di Halaman Reward**
Progress tersimpan dan dapat di-load kapan saja.

### 3️⃣ **Tombol "Coba Lagi"**
- Klik tombol → **Auto reset progress**
- Kembali ke game → Main fresh dari awal

---

## 🔧 Fungsi JavaScript

### **lvl1t1_checkIfCompleted()**
Cek apakah level sudah diselesaikan.
```javascript
const data = lvl1t1_checkIfCompleted();
// Returns: { isCompleted: true/false, score, stars, time }
```

### **lvl1t1_saveCompletion(score, stars, time)**
Simpan progress ke localStorage.
```javascript
lvl1t1_saveCompletion(750, 3, 45);
```

### **lvl1t1_resetProgress()**
Hapus semua saved data (fresh start).
```javascript
lvl1t1_resetProgress();
```

---

## 🧪 Testing Manual

### **Cek Progress di Console**
```javascript
// Buka browser console (F12)
lvl1t1_checkIfCompleted()
// Output: { isCompleted: true, score: 750, stars: 3, time: 45 }
```

### **Reset Progress Manual**
```javascript
lvl1t1_resetProgress()
// Progress terhapus!
```

### **Lihat LocalStorage**
```javascript
localStorage.getItem('lvl1t1_completed')     // "true"
localStorage.getItem('lvl1t1_finalScore')    // "750"
localStorage.getItem('lvl1t1_finalStars')    // "3"
localStorage.getItem('lvl1t1_finalTime')     // "45"
```

---

## 🎮 User Flow

```
[Main Game]
    ↓
[Selesaikan 5 Benda]
    ↓
[Save Progress] ← OTOMATIS!
    ↓
[Reward Page]
    ├─ Home → MainMenu
    ├─ Coba Lagi → Reset Progress & Restart
    └─ Next Game → Level 1 Tingkat 2
```

---

## ⚠️ Catatan

1. **Browser Private Mode**: Progress tidak tersimpan di Incognito/Private mode
2. **Clear Cache**: Jika clear browser data, progress hilang
3. **Beda Browser**: Progress tidak sync antar browser (Chrome vs Firefox)
4. **Beda Device**: Progress tersimpan per device

---

## 🔍 Troubleshooting

**Q: Progress tidak tersimpan?**
- Cek console: ada error `localStorage`?
- Pastikan bukan mode Private
- Test: `localStorage.setItem('test', '123')`

**Q: Mau hapus progress semua level?**
```javascript
localStorage.clear() // Hapus SEMUA data
```

**Q: Mau hapus hanya Level 1 Tingkat 1?**
```javascript
lvl1t1_resetProgress()
```

---

## 📝 Update Log

- **v1.0** (12 Nov 2025): Initial implementation
  - Auto save on completion
  - Reset progress via "Coba Lagi"
  - LocalStorage persistence
